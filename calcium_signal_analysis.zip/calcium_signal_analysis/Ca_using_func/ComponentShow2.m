function ComponentShow2(Component_num, Data, Mice, ID_a, mu, Coeff, Explained, fps, LineColors)
for Component_ID = 1:Component_num
    figure;
    title(['Component ' num2str(Component_ID) ' : ' num2str(int32(Explained(Component_ID))) '%']);
    axis square;
    hold on;
    n1 = numel(Data{1}(1,:));
    for r = 1:numel(ID_a)/numel(Mice)
        score_r = [];
        r1 = find(ID_a == r);
        for k = 1:numel(Mice)
            data1 = Data{r1(k)}';
%             data1_adjust = (data1 - repmat(mu(k1:k2),size(data1,1),1));
            data1_adjust = (data1);
            score1 = data1_adjust*Coeff(:,Component_ID);
            score_r = [score_r; score1'];
        end
        plot_line_fill(score_r,fps,LineColors(r,:),0:1/fps:(n1-1)/fps);
    end
end
end