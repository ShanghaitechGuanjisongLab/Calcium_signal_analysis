function [n,start_point,peak,delay_time,area_under_the_curve,d2] = check_spike2(d0,fps,show_button)
arguments
    d0
    fps
    show_button = 0
end
%% 使用说明：检测钙活动
% 输出参数
% n：钙事件数量
% start_point：单次钙事件起始时间（超过设定阈值的第一点，通常略晚于实际起始时间）。
% peak：单次钙事件峰值。
% delay_time：单次钙事件持续时间。
% area_under_the_curve：单次钙事件曲线下面积。
% d2：识别钙事件使用的处理后曲线，可用于检测识别结果。
% 输入参数
% d0：曲线数据。行向量或列向量。
% fps：数据采样频率。
% show_button：展示钙活动事件。1：展示；0：不展示。（检测用）

%% 使用示例
% load('data_20200907_LVIP1_Z1_pre.mat');
% d1 = data_20200907_LVIP1_Z1_pre(:,16,1);
% [n,start_point,peak,delay_time,auc,d2] = check_spike(d1,10);

%%
delay_time_min = 0.25;
slide_window = 0.1;
cut_std = 3; %2.5
slide_window_frame = ceil(slide_window*fps);
% cut_std = 4;
start_point = [];
peak = [];
delay_time = [];
area_under_the_curve = [];
dfmin = ceil(delay_time_min*fps); %delay frame
d1 = d0*0;
for k = 1:slide_window_frame
    d1(1:k) = d1(1:k) + d0(1:k);
    d1(1+k:end) = d1(1+k:end) + d0(1:end-k);%滑窗
end
d1 = d1/(slide_window_frame+1);
nd = numel(d1);
dt = 10;
sd = zeros(1,nd);
for s = 1:dt
    sd(s) = max(d1);
end
for s = dt+1:nd
    sd(s) = std(d1(s-dt:s));
end
% midsd = prctile(sd,25);
% % midsd = median(sd);
% nsd = find(sd < midsd);
% meand = median(d1(nsd));
% d2 = (d1 - meand)/meand;
% stdd = std(d2(nsd));

midsd = prctile_lky(sd,25);
nsd = find(sd < midsd);
meand = median(d1(nsd));
d2 = (d1 - meand)/meand;
stdd = midsd/meand;

d20 = d2;
d2 = d2 - cut_std*stdd;
d2(d2 < 0) = 0;

s1 = 0;

for s = 1:nd
    if s1 < s
        s1 = s;
    end
    if s == s1
        if d2(s) > 0
            for t = s+1:nd
                if d2(t) == 0
                    if t < s + dfmin
                        s1 = t;
                        break;
                    else
                        start_point = [start_point s];
                        peak1 = max(d2(s:t-1))+cut_std*stdd;
                        peak = [peak peak1];
                        auc1 = (mean(d2(s:t-1))+cut_std*stdd)*(t-s)/fps*100;
                        area_under_the_curve = [area_under_the_curve auc1];
                        dlyt1 = t - s;
                        delay_time = [delay_time dlyt1];
                        s1 = t;
                        break;
                    end
                end
            end
        end
    end
end
n = numel(start_point);

if show_button == 1
    figure;plot((d0 - mean(d0))/mean(d0),'b');
    hold on;
    plot(d20,'k');
    plot(d2+cut_std*stdd,'r');scatter(start_point,d2(start_point)+cut_std*stdd,area_under_the_curve*10,'r','LineWidth',2);
end


