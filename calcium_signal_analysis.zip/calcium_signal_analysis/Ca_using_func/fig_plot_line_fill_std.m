function [xmi,xma,ymi,yma] = fig_plot_line_fill_std(a1,fps,c1,x_input)
[ax,ay] = size(a1);
if nargin < 2
    c1 = rand(1,3);
    fps = 1;
end
if ax > 1
    meana1 = mean(a1);
    stda1 = std(a1);
else
    meana1 = a1;
    stda1 = zeros(1,ay);
end
dt = 1/fps;
if nargin > 3
    x0 = x_input;
else
    x0 = dt:dt:ay*dt;
end
xmi = 0;
xma = (ay + 1)*dt;
%size(x1)
%size(meana1)


x1 = zeros(2,ay);
x1(1,:) = x0;
x1(2,:) = x1(1,:);
y1 = zeros(2,ay);
y1(1,:) = meana1 - stda1;
y1(2,:) = meana1 + stda1;
ymi = min(y1(1,:));
yma = max(y1(2,:));
wtc = [1 1 1];
c2 = c1*1/3 + wtc*2/3;
x1 = x0;
x2 = x1(end:-1:1);
y1 = meana1 - stda1;
y2 = meana1 + stda1;
y2 = y2(end:-1:1);
fill([x1,x2],[y1,y2],c2,'EdgeColor',[1 1 1],'FaceAlpha','0.3','EdgeAlpha','0');alpha(0.3);
hold on
plot(x1,meana1,'Color',c1,'LineWidth',1);alpha(1);
hold on
%pause(0.01);
% x = [1 1 1
%     2 2 2];
% y = [3 4 2
%     6 2 3];
%plot(x,y,'Color',[1 0 0])