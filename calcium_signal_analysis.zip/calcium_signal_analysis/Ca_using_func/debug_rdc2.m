function bug_no = debug_rdc2(rd_c2)
bug_no = [];
[~,xr,yr] = size(rd_c2);
ok = 1;
for k = 1:yr
    for r = 1:xr
        d1 = rd_c2(1,r,k).d;
        u = find(abs(d1) < 10^(-15));
        if numel(u) > 5
            ok = 0;
            bug_no = [bug_no k];
            fprintf([num2str(k) ' ']);
            [xd,~] = size(d1);
            figure;
            for s = 1:xd
                u1 = find(abs(d1(s,:)) < 10^(-10));
                if numel(u1) > 5
                    plot(d1(s,:));
                end
            end
            break;
        end
    end
end
if ok == 1
    fprintf('Done.');
end
fprintf('\n');