function all_type_trace_plot(data_all)

%展示时间步长
sfps = 100;
[nctx,ncty] = size(data_all);
mi_me = [];
ma_me = [];
for k = 1:nctx
    mi_me{k} = 0;
    ma_me{k} = 0;
end
for k = 1:nctx
    if numel(data_all{k,1}) > 0
        for r = 1:ncty
            if size(data_all{k,r},1) > 1
                meand = mean(data_all{k,r});
            else
                meand = data_all{k,r};
            end
            mime1 = min(meand);
            mame1 = max(meand);
            if mime1 < mi_me{k}
                mi_me{k} = mime1;
            end
            if mame1 > ma_me{k}
                ma_me{k} = mame1;
            end
        end
    end
end

mibd = [];
mabd = [];
for k = 1:nctx
    mibd{k} = mi_me{k}*1.2;
    mabd{k} = ma_me{k}*1.2;
end

figure;
for k = 1:nctx
    if numel(data_all{k,1}) > 0
        for r = 1:ncty
            r1 = (k - 1)*ncty + r;
            subplot(nctx,ncty,r1);
            [xd,yd] = size(data_all{k,r});
            xx = (1:yd)./sfps;
            xx = repmat(xx,xd,1);
            plot(xx',data_all{k,r}','k');
            pause(0.5);
        end
    end
end