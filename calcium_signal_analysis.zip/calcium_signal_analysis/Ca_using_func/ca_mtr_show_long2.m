function [positive_cell_ID,data_all,type_cell_ID,data_else] = ca_mtr_show_long2(p_all,mtr,fps,name_all,show_type,chosen_type,positive_cell_button,options)
arguments
    p_all
    mtr
    fps
    name_all
    show_type
    chosen_type
    positive_cell_button
    options.positive_cell_ID = []
    options.show_button = 1
    options.wcut = 4.6%4.6
	options.show_trial_n = []
    options.sort_time = [2 10]
    options.sort_button = 1
    options.time_len = 10
end
positive_cell_ID = options.positive_cell_ID;
show_button = options.show_button;
wcut = options.wcut;
show_trial_n = options.show_trial_n;
sort_time = options.sort_time;
sort_button = options.sort_button;
time_len = options.time_len;
% ca_mtr_show_long2(p_all,odsf,wcut=6,sort_time =[3 4],show_button=4);
%% 使用说明：各项刺激情形下神经元Ca活动响应情况展示
%n：数据文件编号
% positive_cell_ID：阳性细胞编号。数据格式：{1,n}
% data_all：作图用数据。数据格式：{cell_type,stimulus_type}(cell_no,time)
% type_cell_ID：各类型阳性细胞编号。
% data_else：非阳性神经元数据。格式与data_all一致。
% 后三项为可选参数
% positive_cell_button：阳性细胞选择。1：全部阳性，0：全部神经元。-1：可以输入所选择细胞编号。
% positive_cell_ID：阳性细胞编号。仅当button选择-1时使用。
% show_button： 默认值展示结果。1：展示结果。0：仅计算阳性神经元。2：仅展示热度图。
% wcut：阳性细胞阈值。默认值4.6。一般不做修改。
% show_trial_n：仅统计单trial数据时使用，非空时mtr应替换为atr。
% sort_time：按照一段时间内均值对神经元进行分类重排。默认值[2 10]
% sort_button：1：按正值排序。-1：按负值排序。
% time_len：数据展示长度。默认值10。
% 详见：ca_ana_main_vip.m 和 ca_ana_main_learning.m
% 2021/08/25

%% 使用示例一：使用全部参数
%%
% clear;
% data_num = 3; %选择文件夹数目
% %以下为待操作的若干文件夹，其中mat文件已按照对应顺序排好
% data_path{1} = 'H:\rdc2_adjust\L25_learn_long\Day1_L5';
% data_path{2} = 'H:\rdc2_adjust\L25_learn_long\Day10_L5';
% data_path{3} = 'H:\rdc2_adjust\L25_learn_long\Day10_L5_behav';
% 
% %数据预处理部分
% p_all = [];
% atr = [];
% mtr = [];
% amp = [];
% astt = [];
% mstt = [];
% cell_num = [];
% name_all = [];
% 
% 
% %选择需要展示的刺激类型。
% %注意：对应数据中必须包含响应刺激类型！！
% % %a,b为刺激编号，与密码表对应，详见get_t_name.m。
% % %n为文件夹编号
% %例：[a1,a2;b1,b2;n1,n2]表示需要查看n1天的(a1,b1)刺激响应和n2天的(a2,b2)刺激响应。
% show_type = [1 3 2 5 1 5 5 5 3
%              1 1 1 1 1 2 1 1 2
%              1 1 1 1 3 3 3 2 1];
% %选择需要挑选阳性细胞的刺激类型，仅需选择show_type对应列的编号即可。
% %例：[2 4]表示需要挑选show_type第二列和第四列的阳性细胞进行展示。
% % chosen_type = [1 2 5];
% 
% %阳性细胞选择。1：全部阳性，0：全部神经元。-1：可以输入所选择细胞编号。
% positive_cell_button = 1;
% 
% cell_ID = [];
% switch positive_cell_button
%     case -1
% %         cell_ID{1} = [14,18,23,24,27,30,33,40,41,46,49,50,55,57,58,60,61,62,66,69,71,72,73,74,76,77,82,85,88,89,90,91,92,96,97,98,100,102,106,107,109,110,115,116,118,119,120,123,125,126,129,131,132,133,137,139,140,142,143,144,151,153,155,160,162,163,164,168,170,173,176,177,179,180,196,197,198,199,200,201,203,204,206,215,230,244,251,255,256,266,272];
%         cell_ID{2} = [18,28,30,38,40,41,42,46,57,59,67,75,82,97,100,101,106,107,108,109,111,115,117,119,120,122,130,131,132,134,139,140,141,142,143,145,148,149,151,152,153,154,155,158,159,160,162,163,164,165,166,168,170,175,177,179,181,182,183,184,185,186,204,208,210,211,215,218,219,221,222,224,226,227,230,235,236,237,246,247,250,266,267,270,274,280,281,287,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,317,318,319,320,321,322,325,327,331,332,337];
%         cell_ID{3} = [];
% %         cell_ID{2} = [4,10,17,19,20,25,26,28,32,36,38,43,53,54,56,57,59,60,61,62,64,68,69,70,72,74,75,81,82,83,84,85,86,90,91,92,94,95,99,102,111,115,116,119,120,121,123,126,128,129,131,134,137,138,139,145,146,147,148,151,154,159,166,172,175,176,177,185,188,190,192,193,200,203,205,208,213,220,221,236,237,241,244,245,246,248,250,251,252,253,254,261,264,271,273,278,283,286,289,290,291,293,297,301,307,309,313,317,321,323,329,331,335];
% %         cell_ID{2} = [25,28,32,38,57,61,68,69,70,72,75,83,85,94,99,116,119,120,121,123,126,134,145,175,176,177,185,190,192,193,203,208,213,221,236,252,289,291,313,331];
% end
% %数据展示部分 
% %注意：chosen_type之后为可选参数，可省略。
% % mean_adjust_button默认值需要矫正散射光
% % positive_cell_button默认值全部阳性神经元
% 
% wcut = 2.7;
% 
% stats_time = [2 4];
% for k = 1:data_num
%     [p_all1{k},atr{k},mtr{k},amp{k},astt{k},mstt{k},fps,cell_num,name_all] = FolderFun(@(a)trace_ana_long(a,stats_time),data_path{k},"UniformOutput",false);
% end
% 
% 
% 
% show_trial_n = [];
% positive_cell_button = 1;
% show_button = 1;
% chosen_type = [2];
% [cell_ID1,data_all,type_cell_IDa,data_else] = ca_mtr_show_long2(p_all1,mtr,fps,name_all,show_type,chosen_type,positive_cell_button,...
%     wcut = wcut);
%% 使用示例二：仅统计部分trial数据 （待更新）
% clear;
% data_num = 1; %选择文件夹数目
% %以下为待操作的若干文件夹，其中mat文件已按照对应顺序排好
% data_path1{1} = 'H:\rdc2_adjust\L25_screening\L2';
% 
% 
% %数据预处理部分
% p_all1 = [];
% atr1 = [];
% mtr1 = [];
% amp1 = [];
% astt1 = [];
% mstt1 = [];
% cell_num1 = [];
% name_all1 = [];
% for k = 1:data_num
%     [p_all1{k},atr1{k},mtr1{k},amp1{k},astt1{k},mstt1{k},fps,cell_num1,name_all1] = FolderFun(@trace_ana_long,data_path1{k},"UniformOutput",false);
% end
% 
% %以下为待操作的若干文件夹，其中mat文件已按照对应顺序排好
% data_path2{1} = 'H:\rdc2_adjust\L25_screening\L5';
% 
% 
% %数据预处理部分
% p_all2 = [];
% atr2 = [];
% mtr2 = [];
% amp2 = [];
% astt2 = [];
% mstt2 = [];
% cell_num2 = [];
% name_all2 = [];
% for k = 1:data_num
%     [p_all2{k},atr2{k},mtr2{k},amp2{k},astt2{k},mstt2{k},fps,cell_num2,name_all2] = FolderFun(@trace_ana_long,data_path2{k},"UniformOutput",false);
% end
% 
% %选择需要展示的刺激类型。
% %注意：对应数据中必须包含响应刺激类型！！
% % %a,b为刺激编号，与密码表对应，详见get_t_name.m。
% % %n为文件夹编号
% %例：[a1,a2;b1,b2;n1,n2]表示需要查看n1天的(a1,b1)刺激响应和n2天的(a2,b2)刺激响应。
% show_type = [1 3 5 3 5 2 4
%              1 1 1 2 2 1 1
%              1 1 1 1 1 1 1];
% %选择需要挑选阳性细胞的刺激类型，仅需选择show_type对应列的编号即可。
% %例：[2 4]表示需要挑选show_type第二列和第四列的阳性细胞进行展示。
% % chosen_type = [1 2 5];
% 
% 
% %散射光矫正。1：需要矫正，0：不需要矫正。
% mean_adjust_button = 0;
% 
% %阳性细胞选择。1：全部阳性，0：全部神经元。-1：可以输入所选择细胞编号。
% positive_cell_button = 1;
% 
% switch positive_cell_button
%     case {0,1}
%         cell_ID = [];
%     case -1
% %         cell_ID{1} = [14,18,23,24,27,30,33,40,41,46,49,50,55,57,58,60,61,62,66,69,71,72,73,74,76,77,82,85,88,89,90,91,92,96,97,98,100,102,106,107,109,110,115,116,118,119,120,123,125,126,129,131,132,133,137,139,140,142,143,144,151,153,155,160,162,163,164,168,170,173,176,177,179,180,196,197,198,199,200,201,203,204,206,215,230,244,251,255,256,266,272];
%         cell_ID{2} = [18,28,30,38,40,41,42,46,57,59,67,75,82,97,100,101,106,107,108,109,111,115,117,119,120,122,130,131,132,134,139,140,141,142,143,145,148,149,151,152,153,154,155,158,159,160,162,163,164,165,166,168,170,175,177,179,181,182,183,184,185,186,204,208,210,211,215,218,219,221,222,224,226,227,230,235,236,237,246,247,250,266,267,270,274,280,281,287,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,317,318,319,320,321,322,325,327,331,332,337];
%         cell_ID{3} = [];
% %         cell_ID{2} = [4,10,17,19,20,25,26,28,32,36,38,43,53,54,56,57,59,60,61,62,64,68,69,70,72,74,75,81,82,83,84,85,86,90,91,92,94,95,99,102,111,115,116,119,120,121,123,126,128,129,131,134,137,138,139,145,146,147,148,151,154,159,166,172,175,176,177,185,188,190,192,193,200,203,205,208,213,220,221,236,237,241,244,245,246,248,250,251,252,253,254,261,264,271,273,278,283,286,289,290,291,293,297,301,307,309,313,317,321,323,329,331,335];
% %         cell_ID{2} = [25,28,32,38,57,61,68,69,70,72,75,83,85,94,99,116,119,120,121,123,126,134,145,175,176,177,185,190,192,193,203,208,213,221,236,252,289,291,313,331];
% end
% %数据展示部分 
% %注意：chosen_type之后为可选参数，可省略。
% % mean_adjust_button默认值需要矫正散射光
% % positive_cell_button默认值全部阳性神经元
% nm = numel(name_all1);
% wcut = 2.7;
% 
% show_button = 1;
% data_trial_n = 1:5;
% chosen_type = [2];
% [positive_cell_ID1,data_all1,type_cell_ID1,data_else1] = ca_mtr_show_long(p_all1,atr1,fps,name_all1,show_type,chosen_type,mean_adjust_button,positive_cell_button,cell_ID,show_button,wcut,data_trial_n);
% chosen_type = [4];
% [positive_cell_ID2,data_all2,type_cell_ID2,data_else2] = ca_mtr_show_long(p_all1,atr1,fps,name_all1,show_type,chosen_type,mean_adjust_button,positive_cell_button,cell_ID,show_button,wcut,data_trial_n);
%%

[~,ncty] = size(show_type);
nctx = numel(chosen_type);
nm = numel(name_all);
nd = numel(mtr);

ndvm = [];
ndvm_else = [];
stp = show_type;
nc = zeros(1,nm);%number of cells
npc = zeros(1,nm);
for k = 1:nm
    fprintf([name_all{k} '\n']);
    kns = 0*p_all{1}{k}{1,1};
    for r = 1:nctx
        r1 = chosen_type(r);
        dv11 = p_all{stp(3,r1)}{k}{stp(1,r1),stp(2,r1)};
        kn11 = dv11 > wcut*mean(dv11);
        kns = kns + kn11;
		if r == 1
			nc(k) = numel(dv11);
		end
    end
    switch positive_cell_button
        case -1
            ndvm{k} = positive_cell_ID{k};
            kns1 = kns*0;
            kns1(ndvm{k}) = 1;
            ndvm_else{k} = find(kns1 == 0);
        case 1
            ndv = find(kns > 0);
            ndvm{k} = ndv;
            ndve = find(kns == 0);
            ndvm_else{k} = ndve;
        case 0
            ndv = find(kns > -1);
            ndvm{k} = ndv;
            ndve = find(kns == -1);
            ndvm_else{k} = ndve;
	end
	npc(k) = numel(ndvm{k});
end
positive_cell_ID = ndvm;
type_cell_ID = [];

nc_sum = sum(nc);
npc_sum = sum(npc);
if npc_sum == nc_sum
	fprintf([num2str(nc_sum) ' cells in ' num2str(nm) 'mice\n']);
	for k = 1:nm
		fprintf([num2str(npc(k)) ' ']);
	end
	fprintf('\n');
else
	fprintf([num2str(npc_sum) '/' num2str(nc_sum) ' cells in ' num2str(nm) 'mice\n']);
	for k = 1:nm
		fprintf([num2str(npc(k)) '/' num2str(nc(k)) ' ']);
	end
	fprintf('\n');
end

%展示时间步长
sfps = 100;
%第一维度细胞类别，第二维度刺激类型
data_all = [];
data_else = [];
for k = 1:nctx
    for r = 1:ncty
        data_all{k,r} = [];
        data_else{1,r} = [];
    end
end
for k = 1:nm
    for r = 1:nctx
        type_cell_ID{k,r} = [];
    end
end

if numel(show_trial_n) > 0
	atr = mtr;
	mtr1 = [];
	for k = 1:numel(atr)
		for r = 1:nm
			[xa,ya] = size(atr{k}{r});
			for s = 1:xa
				for t = 1:ya
					if numel(atr{k}{r}{s,t}{1}) > 0
						try
							[~,yn] = size(atr{k}{r}{s,t}{1});
							ncell = numel(atr{k}{r}{s,t});
							d1 = zeros(ncell,yn);
							for u = 1:ncell
								if numel(show_trial_n) == 1
									d1(u,:) = atr{k}{r}{s,t}{u}(show_trial_n,:);
								else
									d1(u,:) = mean(atr{k}{r}{s,t}{u}(show_trial_n,:));
								end
							end
							mtr1{k}{r}{s,t} = d1;
						catch
							fprintf('Some types of stimuli do not contain enough trials.\n');
						end
					end
				end
			end
		end
	end
	mtr = mtr1;
end
        
for k = 1:nm
    amd = [];%all mean data
    fps1 = round(fps{k});
    for r = 1:nctx
        r1 = chosen_type(r);
        d1 = mtr{stp(3,r1)}{k}{stp(1,r1),stp(2,r1)}(ndvm{k},:);
        [xd,yd] = size(d1);
        start_time = round(sort_time(1)*round(fps1)+1);
        end_time = round(sort_time(2)*round(fps1)+1);
        end_time = min(end_time,yd);
        md1 = mean(d1(:,start_time:end_time),2);
        amd = [amd md1];
    end
    if nctx == 1
        maamd = amd'*0+1;
    else
        if sort_button == 1
            [~,maamd] = max(amd');
        else
            [~,maamd] = min(amd');
        end
    end
    for r = 1:ncty
        d1 = mtr{stp(3,r)}{k}{stp(1,r),stp(2,r)}(ndvm{k},:);
        [xd,yd] = size(d1);
        d2 = mtr{stp(3,r)}{k}{stp(1,r),stp(2,r)}(ndvm_else{k},:);
        if xd > 0
            xx = 0:round(time_len*sfps) - 1;
            xx0 = xx/sfps*fps1 + 1;
            xx1 = floor(xx/sfps*fps1) + 1;
            xx2 = ceil(xx/sfps*fps1) + 1;
            for s = 1:nctx
                ns = maamd == s;
                type_cell_ID{k,s} = positive_cell_ID{k}(ns);
                ds = d1(ns,:);
                [xds,~] = size(ds);
                xxw1 = xx2 - xx0;
                xxw2 = 1 - xxw1;
                xxw1 = repmat(xxw1,xds,1);
                xxw2 = repmat(xxw2,xds,1);
                data_all{s,r} = [data_all{s,r}; ds(:,xx1).*xxw1 + ds(:,xx2).*xxw2];
            end
            [xd2,~] = size(d2);
            xxw1 = xx2 - xx0;
            xxw2 = 1 - xxw1;
            xxw1 = repmat(xxw1,xd2,1);
            xxw2 = repmat(xxw2,xd2,1);
            data_else{1,r} = [data_else{1,r}; d2(:,xx1).*xxw1 + d2(:,xx2).*xxw2]; 
        end
    end
end

if show_button == 1
    for k = 1:nctx
        k1 = chosen_type(k);
        d1 = data_all{k,k1};
        [xd,yd] = size(d1);
        start_time = round(sort_time(1)*round(sfps)+1);
        end_time = round(sort_time(2)*round(sfps)+1);
        end_time = min(end_time,yd);
        md1 = mean(d1(:,start_time:end_time),2);
        if sort_button == 1
            [~,nod] = sort(md1,'descend');
        else
            [~,nod] = sort(md1,'ascend');
        end
        for r = 1:ncty
            data_all{k,r} = data_all{k,r}(nod,:);
        end
    end

    mean_d = [];
    figure;
    for k = 1:ncty
        d1 = [];
        for r = 1:nctx
            d1 = [d1; data_all{r,k}];
        end
        subplot(1,ncty,k);
        imagesc(d1);
        kr1 = mean(d1(:,round(2.3*sfps):round(time_len*sfps))');
        mean_d = [mean_d; kr1];
        colormap(rbmap);
%         caxis([-0.5 0.5]);
        caxis([-2,2]);%%20240418 caxis([-0.5,0.5]);
        axis off;
    end

    crmd1 = corrcoef(mean_d);
%     figure;
%     imagesc(crmd1);caxis([0 1]);
%     crmd2 = corrcoef(mean_d');
%     figure;
%     imagesc(crmd2);caxis([0.5 1]);

    figure;
    for k = 1:ncty
        d1 = [];
        for r = 1:nctx
            d1 = [d1; data_all{r,k}];
        end
        d1 = [d1; data_else{1,k}];
        subplot(1,ncty,k);
        imagesc(d1);
        colormap(rbmap);
        caxis([-0.5 0.5]);
        hold on;
        name1 = get_t_name(stp(1,k),stp(2,k));
        name1(name1 == '_') = ' ';
        title(name1);
        axis off;
    end
end