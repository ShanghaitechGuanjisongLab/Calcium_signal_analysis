function y = angle_ab(a,b)
a1 = zeros(numel(a),1);
b1 = zeros(numel(b),1);
a1(:) = a;
b1(:) = b;
c = (a1'*b1)/(a1'*a1)^(1/2)/(b1'*b1)^(1/2);
y = acos(c);