function fig_show_single_trial(show_type,atr,fps,plot_type,show_cell_ID,show_trial_n,d_line,marker_button,slide_window,blank_s,start_time)
arguments
    show_type
    atr
    fps
    plot_type
    show_cell_ID
    show_trial_n = 8
    d_line = 1
    marker_button = 1
    slide_window = 5
    blank_s = 2 %显示间隔
    start_time = 1
end
%% 使用说明：单个trial下神经元活动情况展示
% 注：图片右下角为图像标尺，横轴：2s，纵轴：50%。
% show_type：详见：ca_ana_main_vip.m
% atr：详见：ca_ana_main_vip.m
% fps：详见：ca_ana_main_vip.m
% plot_type：所选show_type中展示类型编号
% show_cell_ID：展示细胞编号。格式同positive_cell_ID，详见：ca_ana_main_vip.m
% 后五项为可选参数
% show_trial_n：展示trial数量。默认值8。
% d_line：线条之间间隔，1=100%。默认值1。
% marker_button：刺激时间点标记。1：展示；0：不展示。默认值1。
% slide_window：滑窗展示中滑窗宽度，1为无滑窗。默认值5。
% blank_s：trial之间间隔（单位：s）。默认值2。
% 详见：ca_ana_main_vip.m 和 ca_ana_main_learning.m

%% 使用示例
% %选择需要展示的刺激类型。
% clear;
% data_num = 1; %选择文件夹数目
% %以下为待操作的若干文件夹，其中mat文件已按照对应顺序排好
% data_path{1} = 'H:\rdc2_adjust\PV_bas\PV_pre';
% 
% %数据预处理部分
% p_all = [];
% atr = [];
% mtr = [];
% amp = [];
% astt = [];
% mstt = [];
% cell_num = [];
% name_all = [];
% for k = 1:data_num
%     [p_all{k},atr{k},mtr{k},amp{k},astt{k},mstt{k},fps,cell_num,name_all] = FolderFun(@trace_ana,data_path{k},"UniformOutput",false);
% end
% 
% %选择需要展示的刺激类型。
% %注意：对应数据中必须包含响应刺激类型！！
% % %a,b为刺激编号，与密码表对应，详见get_t_name.m。
% % %n为文件夹编号
% %例：[a1,a2;b1,b2;n1,n2]表示需要查看n1天的(a1,b1)刺激响应和n2天的(a2,b2)刺激响应。
% show_type = [1,3,2,5
%              1,1,1,1
%              1,1,1,1];
% %选择需要挑选阳性细胞的刺激类型，仅需选择show_type对应列的编号即可。
% %例：[2 4]表示需要挑选show_type第二列和第四列的阳性细胞进行展示。
% % chosen_type = [1 2 5];
% chosen_type = 1:4;
% 
% %散射光矫正。1：需要矫正，0：不需要矫正。
% mean_adjust_button = 0;
% 
% %阳性细胞选择。1：全部阳性，0：全部神经元。-1：可以输入所选择细胞编号。
% positive_cell_button = 0;
% 
% %数据展示部分 
% %注意：chosen_type之后为可选参数，可省略。
% % mean_adjust_button默认值需要矫正散射光
% % positive_cell_button默认值全部阳性神经元
% [positive_cell_ID,data_all,type_cell_ID] = ca_mtr_show(p_all,mtr,fps,name_all,show_type,chosen_type,mean_adjust_button,positive_cell_button,cell_ID);
% show_single_trial(show_type,atr,fps,4,positive_cell_ID);

%%

nm = numel(fps);
cell_ID1 = [];
mouse_ID1 = [];
for k = 1:nm
    c1 = show_cell_ID{k};
    nc1 = numel(c1);
    cell_ID1 = [cell_ID1 c1];
    mouse_ID1 = [mouse_ID1 ones(1,nc1)*k];
end

%3 6 3 38 6
%show data
xxa = [];
yya = [];

ydn = 0;
for r = 1:numel(cell_ID1)
    m1 = mouse_ID1(r);
    r1 = cell_ID1(r);
    data = atr{show_type(3,plot_type)}{m1}{show_type(1,plot_type),show_type(2,plot_type)}{r1};
    [xd,yd] = size(data);
	if yd > 0
		ydn = yd;
	end
    fps1 = fps{m1};
    xx1 = (1:yd)/fps1;
    xx = [];
    for k = 1:show_trial_n
        xx = [xx xx1'+(yd/fps1 + blank_s)*(k - 1)];
    end
    d1 = data(1:show_trial_n,:)';
    d2 = d1;
    sumd0 = d1(1,:)*0;
    for s = 1:slide_window
        sumd0 = sumd0 + d1(s,:);
        d2(s,:) = sumd0/s;
    end
    sumd1 = d1(slide_window:end,:)*0;
    for s = 1:slide_window
        sumd1 = sumd1 + d1(s:end+s-slide_window,:);
    end
    sumd1 = sumd1/slide_window;
    d2(slide_window:end,:) = sumd1;
    yy = d2 + r*d_line;
    xxa = [xxa xx];
    yya = [yya yy];
end

%show start time
xxt1 = [];
yyt1 = [];
xxt2 = [];
yyt2 = [];
marker_height = .6;
marker_wide = .6;
for k = 1:show_trial_n
    h1 = d_line-0.2;
    if show_type(1,plot_type) == 3 || show_type(1,plot_type) == 5
        t1 = (ydn/fps1 + blank_s)*(k - 1) + start_time;
        xx1 = [t1; t1+marker_wide/2; t1-marker_wide/2];
        yy1 = [h1; h1-marker_height; h1-marker_height];
        xxt1 = [xxt1 xx1];
        yyt1 = [yyt1 yy1];
    end
    if show_type(1,plot_type) == 5 || show_type(1,plot_type) == 2
        t1 = (ydn/fps1 + blank_s)*(k - 1) + start_time + 0.3;
        xx1 = [t1; t1+marker_wide/2; t1-marker_wide/2];
        yy1 = [h1; h1-marker_height; h1-marker_height];
        xxt2 = [xxt2 xx1];
        yyt2 = [yyt2 yy1];
    end
end
%show bar
xxb = [];
yyb = [];
x1 = (ydn/fps1 + blank_s)*show_trial_n + 5;
x2 = x1 + 2;
y1 = 0;
y2 = 1;%0.5
xxb = [x1 x1 x2];
yyb = [y2 y1 y1];


figure;
plot(xxa,yya,'k','LineWidth',1);
hold on;
if marker_button == 1
    if numel(xxt1) > 0
        fill(xxt1,yyt1,'b','EdgeAlpha',0);
    end
    if numel(xxt2) > 0
        fill(xxt2,yyt2,'r','EdgeAlpha',0);
    end
end
plot(xxb,yyb,'k','LineWidth',1);
text(x1,y2,'100%');
text(x2,y1,'2s');
axis off;