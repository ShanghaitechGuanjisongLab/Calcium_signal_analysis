function ComponentShow3(Component_num, Data, Mice, ID_a, Coeff, Explained, fps, LineColors)
for Component_ID = 1:Component_num
    figure;
    u = ceil(numel(Mice)/3);
    tiledlayout(u,3);
    
    n1 = numel(Data{1}(1,:));
    for k = 1:numel(Mice)
        nexttile;
        title(['Component ' num2str(Component_ID) ' : ' num2str(int32(Explained(Component_ID))) '%']);
        axis square;
        hold on;
        for r = 1:numel(ID_a)
            data1 = Data{numel(ID_a)*(k-1) + ID_a(r)}';
%             data1_adjust = (data1 - repmat(mu(k1:k2),size(data1,1),1));
            data1_adjust = (data1);
            score1 = data1_adjust*Coeff(:,Component_ID);
            plot(0:1/fps:(n1-1)/fps,score1,'Color',LineColors(r,:));
        end
%         0:1/fps:(n1-1)/fps
        
    end
end
end