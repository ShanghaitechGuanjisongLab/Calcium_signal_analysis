function [xmi,xma,ymi,yma] = fill_bar(a1,c1,base1)
%% example
% a{1} = rand(1,5);
% a{2} = rand(1,5);
% a{3} = rand(1,5);
% c = [1 0 0];
% figure;plot_bar(a,c);

%%
arguments
    a1
    c1 = rand(numel(a1),3)
    base1 = 0
end
[ay] = numel(a1);
meana1 = zeros(1,ay);
stda1 = zeros(1,ay);
for k = 1:ay
    meana1(k) = mean(a1{k});
    stda1(k) = std(a1{k});
    if meana1(k) < 0
        stda1(k) = -stda1(k);
    end
end

dt = 1;
x1 = dt:dt:ay*dt;
xmi = 0;
xma = (ay + 1)*dt;
%size(x1)
%size(meana1)
% plot(x1,meana1,'Color',c1,'LineWidth',2);
hold on

x0(1,:) = dt:dt:ay*dt;
x0(2,:) = x0(1,:);
y0 = zeros(2,ay);
y0(1,:) = meana1;
y0(2,:) = meana1 + stda1;
ymi = min(y0(1,:));
yma = max(y0(2,:));
% plot(x1,y1,'Color',c1,'LineWidth',1)
% hold on
ln1 = 0.191;
ln2 = 0.309;
x1 = zeros(4,ay);
x2 = zeros(2,ay);
x3 = zeros(2,ay);
x4 = zeros(2,ay);
x1(1,:) = dt:dt:ay*dt;
x1(1,:) = x0(1,:) - dt*ln1;
x1(2,:) = x0(1,:) + dt*ln1;
x1(3,:) = x1(1,:);
x1(4,:) = x1(2,:);
x2(1,:) = x0(1,:) - dt*ln2;
x2(2,:) = x0(1,:) + dt*ln2;
x3(1,:) = x0(1,:) - dt*ln2;
x3(2,:) = x0(1,:) - dt*ln2;
x4(1,:) = x0(1,:) + dt*ln2;
x4(2,:) = x0(1,:) + dt*ln2;
y1 = zeros(4,ay);
y2 = zeros(2,ay);
y3 = zeros(2,ay);
y4 = zeros(2,ay);
y1(1,:) = meana1 - stda1;
y1(2,:) = meana1 - stda1;
y1(3,:) = meana1 + stda1;
y1(4,:) = meana1 + stda1;
y2(1,:) = meana1;
y2(2,:) = meana1;
y3(1,:) = meana1*0+base1;
y3(2,:) = meana1;
y4(1,:) = meana1*0+base1;
y4(2,:) = meana1;
% 

x5 = zeros(4,ay);
y5 = zeros(4,ay);
for k = 1:ay
    color1 = c1{k};
    x5(1,:) = x0(1,k) - dt*ln2;
    x5(2,:) = x0(1,k) + dt*ln2;
    x5(3,:) = x0(1,k) + dt*ln2;
    x5(4,:) = x0(1,k) - dt*ln2;
    y5(1,:) = y5(1,:)*0 + base1;
    y5(2,:) = y5(2,:)*0 + base1;
    y5(3,:) = meana1(k);
    y5(4,:) = meana1(k);

    fill(x5,y5,[0 0 0],'FaceColor',color1,'LineStyle','none');
    plot([x0(:,k) x1(3:4,k) x2(:,k)],[y0(:,k) y1(3:4,k) y2(:,k)],'Color',color1,'LineWidth',1);
end
hold on
plot([0.5 ay+0.5],[base1 base1],'Color',[0 0 0],'LineWidth',1);
set(gca,'xtick',[]);

pause(0.01);
% x = [1 1 1
%     2 2 2];
% y = [3 4 2
%     6 2 3];
%plot(x,y,'Color',[1 0 0])

%需添加功能：去掉横线