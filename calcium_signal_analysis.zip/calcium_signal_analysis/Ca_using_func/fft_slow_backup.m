function dr1 = fft_slow(dr,fps,cut)
ndr = numel(dr);
X = fft(dr);
X(round(ndr*cut/fps):end) = 0;
Y = ifft(X);
dr1 = real(Y);
% if sum(dr.*y1) < sum(dr.*-y1)
%     dr1 = -y1;
% else
%     dr1 = y1;
% end