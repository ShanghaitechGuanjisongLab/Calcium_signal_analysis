%for -2 8 data show
function auc_show_position(raw_data_name1, data_name1, tif_name1, chosen_type, NoSamples, fps1, ch_cn, type_color)
load(raw_data_name1,"cell_edgex","cell_edgey");
load(data_name1,"tag","rd_c2");
c = imread(tif_name1);
c = double(c);
c = (c - min(min(c)))/(max(max(c)) - min(min(c)));
for s = 1:2
    a = [];
    
    for k = 1:numel(tag.type)
        if tag.type(k) == chosen_type(s,1) && tag.t_no(k) == chosen_type(s,2)
            b = [];
            for r = 1:size(rd_c2,3)
                d1 = rd_c2(1,k,r).d;
                d1 = imresize(d1,[size(d1,1),NoSamples]);
                meand1 = mean(d1(:,2*fps1+2:5*fps1+1),2);
                b = [b meand1];
            end
            a = [a; b];
        end
    end
    
    ma = mean(a);
    figure;
    imshow(c);
    hold on;
    for k = 1:size(rd_c2,3)
        xx = mean(cell_edgex(:,ch_cn(k)));
        yy = mean(cell_edgey(:,ch_cn(k)));
        scatter(xx,yy,abs(ma(k))^(1/2)*400,type_color(s,:),'filled');
        hold on;
    end
    axis([0 513 0 513]);
    axis square;
    axis off;
end
end