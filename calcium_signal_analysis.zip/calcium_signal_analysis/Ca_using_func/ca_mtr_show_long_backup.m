function [positive_cell_ID,data_all,type_cell_ID] = ca_mtr_show_long(p_all,mtr,fps,name_all,show_type,chosen_type,mean_adjust_button,positive_cell_button,positive_cell_ID,show_button,wcut)
arguments
    p_all
    mtr
    fps
    name_all
    show_type
    chosen_type
    mean_adjust_button = 0
    positive_cell_button = 1
    positive_cell_ID = []
    show_button = 1
    wcut = 4.6;%4.6
end
% 前2s后8s类型数据处理
%% 使用说明：各项刺激情形下神经元Ca活动响应情况展示
%n：数据文件编号
% positive_cell_ID：阳性细胞编号。数据格式：{1,n}
% data_all：作图用数据。数据格式：{cell_type,stimulus_type}(cell_no,time)
% type_cell_ID：各类型阳性细胞编号。
% 后三项为可选参数
% mean_adjust_button：散射光矫正。1：需要矫正，0：不需要矫正。默认值不需要矫正散射光。
% positive_cell_button：阳性细胞选择。1：全部阳性，0：全部神经元。-1：可以输入所选择细胞编号。
% positive_cell_ID：阳性细胞编号。仅当button选择-1时使用。
% show_button： 默认值展示结果。1：展示结果。0：仅计算阳性神经元。
% wcut：阳性细胞阈值。默认值4.6。一般不做修改。
% 详见：ca_ana_main_vip.m 和 ca_ana_main_learning.m

%% 使用示例一：使用全部参数
% %选择需要展示的刺激类型。
% %注意：对应数据中必须包含响应刺激类型！！
% % %a,b为刺激编号，与密码表对应，详见get_t_name.m。
% % %n为文件夹编号
% %例：[a1,a2;b1,b2;n1,n2]表示需要查看n1天的(a1,b1)刺激响应和n2天的(a2,b2)刺激响应。
% show_type = [1 3 5 3 1 3 3
%              1 1 1 2 1 1 2
%              1 1 1 1 1 2 2];
% %选择需要挑选阳性细胞的刺激类型，仅需选择show_type对应列的编号即可。
% %例：[2 4]表示需要挑选show_type第二列和第四列的阳性细胞进行展示。
% chosen_type = [2 3 4 6 7];
% 
% %散射光矫正。1：需要矫正，0：不需要矫正。
% mean_adjust_button = 1;
% 
% %阳性细胞选择。1：全部阳性，0：全部神经元。-1：可以输入所选择细胞编号。
% positive_cell_button = -1;
% 
% switch positive_cell_button
%     case {0,1}
%         cell_ID = [];
%     case -1
%         cell_ID{1} = [];
%         cell_ID{2} = [22 34 42 62 96 150 179 219 224];
%         cell_ID{3} = [32 40 38 74 77 137 146 197 241 242 330 331];
% end
% %数据展示部分 
% %注意：chosen_type之后为可选参数，可省略。
% % mean_adjust_button默认值需要矫正散射光
% % positive_cell_button默认值全部阳性神经元
% ca_mtr_show(p_all,mtr,fps,name_all,show_type,chosen_type,mean_adjust_button,positive_cell_button,cell_ID);

%% 使用示例二：部分参数选择默认值
% ca_mtr_show(p_all,mtr,fps,name_all,show_type,chosen_type);
%%


[~,ncty] = size(show_type);
nctx = numel(chosen_type);
nm = numel(name_all);
nd = numel(mtr);

ndvm = [];
ndvm_else = [];
stp = show_type;
for k = 1:nm
    fprintf([name_all{k} '\n']);
    kns = 0*p_all{1}{k}{1,1};
    for r = 1:nctx
        r1 = chosen_type(r);
        dv11 = p_all{stp(3,r1)}{k}{stp(1,r1),stp(2,r1)};
        kn11 = dv11 > wcut*mean(dv11);
        kns = kns + kn11;
    end
    switch positive_cell_button
        case -1
            ndvm{k} = positive_cell_ID{k};
            kns1 = kns*0;
            kns1(ndvm{k}) = 1;
            ndvm_else{k} = find(kns1 == 0);
        case 1
            ndv = find(kns > 0);
            ndvm{k} = ndv;
            ndve = find(kns == 0);
            ndvm_else{k} = ndve;
        case 0
            ndv = find(kns > -1);
            ndvm{k} = ndv;
            ndve = find(kns == -1);
            ndvm_else{k} = ndve;
    end
end
positive_cell_ID = ndvm;
type_cell_ID = [];

%展示时间步长
sfps = 100;
%第一维度细胞类别，第二维度刺激类型
data_all = [];
data_else = [];
for k = 1:nctx
    for r = 1:ncty
        data_all{k,r} = [];
        data_else{1,r} = [];
    end
end
for k = 1:nm
    for r = 1:nctx
        type_cell_ID{k,r} = [];
    end
end

switch mean_adjust_button
    case 1
        mtr_adjust = [];
        for k = 1:nm
            for t = 1:nd
                mtr_adjust{t}{k} = [];
                [xm,ym] = size(mtr{t}{k});
                for r = 1:xm
                    for s = 1:ym
                        d1 = mtr{t}{k}{r,s};
                        [xd,yd] = size(d1);
                        my_d1 = mean(d1');
                        me_my_d1 = median(my_d1);
                        d1no = my_d1 < me_my_d1;
                        mean_d1 = mean(d1(d1no,:));
                        mean_d1_matrix = repmat(mean_d1,[xd,1]);
                        d1 = d1 - mean_d1_matrix;
                        mtr_adjust{t}{k}{r,s} = d1;
                    end
                end
            end
        end
    case 0
        mtr_adjust = [];
        for k = 1:nm
            for t = 1:nd
                mtr_adjust{t}{k} = mtr{t}{k};
            end
        end
end
        
for k = 1:nm
    amd = [];%all mean data
    fps1 = round(fps{k});
    for r = 1:nctx
        r1 = chosen_type(r);
        d1 = mtr_adjust{stp(3,r1)}{k}{stp(1,r1),stp(2,r1)}(ndvm{k},:);
        [xd,yd] = size(d1);
        md1 = mean(d1(:,2*round(fps1)+1:end),2);
        amd = [amd md1];
    end
    if nctx == 1
        maamd = amd'*0+1;
    else
        [~,maamd] = max(amd');
    end
    for r = 1:ncty
        d1 = mtr_adjust{stp(3,r)}{k}{stp(1,r),stp(2,r)}(ndvm{k},:);
        [xd,yd] = size(d1);
        d2 = mtr_adjust{stp(3,r)}{k}{stp(1,r),stp(2,r)}(ndvm_else{k},:);
        if xd > 0
            xx = 0:round(10*sfps) - 1;
            xx0 = xx/sfps*fps1 + 1;
            xx1 = floor(xx/sfps*fps1) + 1;
            xx2 = ceil(xx/sfps*fps1) + 1;
            for s = 1:nctx
                ns = maamd == s;
                type_cell_ID{k,s} = positive_cell_ID{k}(ns);
                ds = d1(ns,:);
                [xds,~] = size(ds);
                xxw1 = xx2 - xx0;
                xxw2 = 1 - xxw1;
                xxw1 = repmat(xxw1,xds,1);
                xxw2 = repmat(xxw2,xds,1);
                data_all{s,r} = [data_all{s,r}; ds(:,xx1).*xxw1 + ds(:,xx2).*xxw2];
            end
            [xd2,~] = size(d2);
            xxw1 = xx2 - xx0;
            xxw2 = 1 - xxw1;
            xxw1 = repmat(xxw1,xd2,1);
            xxw2 = repmat(xxw2,xd2,1);
            data_else{1,r} = [data_else{1,r}; d2(:,xx1).*xxw1 + d2(:,xx2).*xxw2]; 
        end
    end
end

if show_button == 1
    for k = 1:nctx
        k1 = chosen_type(k);
        d1 = data_all{k,k1};
        md1 = mean(d1(:,2*round(sfps)+1:end),2);
        [~,nod] = sort(md1,'descend');
        for r = 1:ncty
            data_all{k,r} = data_all{k,r}(nod,:);
        end
    end

    mean_d = [];
    figure;
    for k = 1:ncty
        d1 = [];
        for r = 1:nctx
            d1 = [d1; data_all{r,k}];
        end
        subplot(1,ncty,k);
        imagesc(d1);
        kr1 = mean(d1(:,round(2.3*sfps):round(10*sfps))');
        mean_d = [mean_d; kr1];
        colormap(rbmap);
        caxis([-0.5 0.5]);
        axis off;
    end

    crmd1 = corrcoef(mean_d);
    figure;
    imagesc(crmd1);
    crmd2 = corrcoef(mean_d');
    figure;
    imagesc(crmd2);

    figure;
    for k = 1:ncty
        d1 = [];
        for r = 1:nctx
            d1 = [d1; data_all{r,k}];
        end
        d1 = [d1; data_else{1,k}];
        subplot(1,ncty,k);
        imagesc(d1);
        colormap(rbmap);
        caxis([-0.5 0.5]);
        hold on;
        name1 = get_t_name(stp(1,k),stp(2,k));
        name1(name1 == '_') = ' ';
        title(name1);
    end
end