file_path = uigetdir('','Select data path'); 
addpath(genpath(file_path));
cd(file_path);
filelist = dir([file_path '\*.tif']);
filelist=struct2cell(filelist);
filelist=filelist(1,:);
trial_number=length(filelist);
xn = 4;
yn = 5;
figure;
for k = 1:trial_number
    subplot(xn,yn,k);
    fname = filelist{k};
    gray=imread(fname,'Index',1);
    imagesc(gray);colormap gray;
    hold on;
    axis off;
    fname(fname == '_') = ' ';
    title(fname);
end

