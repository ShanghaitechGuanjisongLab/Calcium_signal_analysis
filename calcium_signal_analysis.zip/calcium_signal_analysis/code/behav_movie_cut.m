file_path = uigetdir('','Select behaviour path');
cd(file_path);
filelist = dir([file_path '\*.avi']);

filelist=struct2cell(filelist);
filelist=filelist(1,:);
trial_number=length(filelist);

mkdir(fullfile(file_path,"Z1"));
fname = filelist{1};
video = VideoReader(fname);
frame = read(video,1);

%读取ROI
Roilist = dir([file_path '\*.roi']);
Roilist=struct2cell(Roilist);
Roilist=Roilist(1,:);

Fid=fopen(Roilist{1},"r","b");
fseek(Fid,8,"bof");
ys=fread(Fid,1,"int16");
xs=fread(Fid,1,"int16");
ye=fread(Fid,1,"int16");
xe=fread(Fid,1,"int16");
fclose(Fid);
as=xe-xs;
bs=ye-ys;
x0=xs;
y0=ys;
a=as;
b=bs;
x1 = x0 + 1/2;
y1 = y0 + 1/2;
y2 = y1 + 1/2 + b/2;
xmi = x1;
xma = xmi + a;
light_pixel = zeros(size(frame,1),size(frame,2));
for ix = xmi+1/2:xma-1/2
	if ix >= 1 && ix <= size(frame,2)
		d = sqrt((b/2)^2-b^2/a^2*(ix - (xmi+xma)/2)^2);
		ymin = round(y2-d);
		ymax = round(y2+d) - 1;
        if ymin < 1
			ymin = 1;
        end
        if ymax > size(frame,1)
			ymax = size(frame,1);
        end
        light_pixel(ymin:ymax,ix) = 1;
	else
		fprintf('Warning! Part of the cell is out of the figure.');
	end
end



fps = 30;
for k = 1:trial_number
    fname = filelist{k};
    video = VideoReader(fname);
    frame = read(video,1);
    data = zeros(size(frame,1),size(frame,2),video.NumFrames);
    light = zeros(1,video.NumFrames);
    for r = 1:video.NumFrames
        frame = read(video,r);
        frame1 = mean(frame,3);
        data(:,:,r) = frame1;
        frame2 = frame(:,:,3);
        light(r) = mean(frame2(logical(light_pixel)));
    end
    
    light1 = abs(light(2:end) - light(1:end-1));
    no_light1 = find(light1 > max(light1)/2);

    no_light2 = [];
    for r = 1*fps+1:numel(light1) - 5*fps
        if light1(r) > max([light1(r-1*fps:r-1) light1(r+1:r+5*fps)])
            no_light2 = [no_light2 r];
        end
    end
    no_light = intersect(no_light1,no_light2);
    figure;
    plot(light1,'b');
    hold on;
    scatter(no_light,light1(no_light),50,'r');

    Z_num = 1;
    WritePaths=strings(Z_num,1);
    mImage = size(frame,1);
    nImage = size(frame,2);
    TagStruct=struct("ImageWidth",mImage,"ImageLength",nImage,"Photometric",Tiff.Photometric.MinIsBlack,"Compression",Tiff.Compression.LZW,"PlanarConfiguration",Tiff.PlanarConfiguration.Chunky,"BitsPerSample",16,"SamplesPerPixel",1);
    
    OutputPaths=strings(Z_num,1);
    ZString="Z"+string(1);
    WritePaths(1)=fullfile(file_path,ZString,ZString+"_"+fname);
    OPs=WritePaths+"."+string(1);
    WriteClients=arrayfun(@(Path)Tiff(Path,"w8"),OPs);
    OutputPaths(:,1)=OPs;
    for r = 1:numel(no_light)
        r1 = no_light(r);
        if r1 < 3 
            start_id = 1;
        else
            start_id = r1-2;
        end
        if r1+round(fps/2) > size(data,3)
            start_id = size(data,3) - round(fps/2);
        end
        for s = start_id:start_id+round(fps/2)
            WC=WriteClients(1);
            WC.setTag(TagStruct);
            WC.write(uint16(data(:,:,s)'));
            WC.writeDirectory;
        end
        WC=WriteClients(1);
        WC.setTag(TagStruct);
        WC.write(uint16(data(:,:,s)'*0+1));
        WC.writeDirectory;
    end
%     OPs=OutputPaths(1,:);
%     TiffMerge(WritePaths(1),OPs);
%     arrayfun(@delete,OPs);

end