file_path = uigetdir('','Select data path'); 
addpath(genpath(file_path));
cd(file_path);

filelist = dir([file_path '\*.tif']);
filelist=struct2cell(filelist);
filelist=filelist(1,:);
trial_number=length(filelist);
%%
ref_region_ID=[];
for i=1:length(filelist)
    ref_region_ID(i)=sum(strfind(filelist{i},'ref'))>0;
end
ref_region_rank=find(ref_region_ID==1);

filelist_old=filelist;
if sum(filelist{ref_region_rank}(1:3)=='ref')==3
filelist{ref_region_rank}(1:4)=[];
filelist{ref_region_rank}=['align_' filelist{ref_region_rank}];
eval(['!rename' [ ' "' [file_path '\' filelist_old{ref_region_rank}] '"' ] [ ' "' filelist{ref_region_rank}] '"' ])
end

%%
filelist = dir([file_path '\*.tif']);
filelist=struct2cell(filelist);
filelist=filelist(1,:);
C1_region=[];C2_region=[];
for i =1:length(filelist)
       C1_region(i)=strfind(filelist{i},'C1')>0;
       C2_region(i)=strfind(filelist{i},'C2')>0;
end
C1_region_ID=find(C1_region==1);
C2_region_ID=find(C2_region==1);

filelist_C1=filelist(C1_region_ID);
filelist_C2=filelist(C2_region_ID);

%%
Red_Data=[];Green_Data=[];RBG_data=[];deltaRBG_data=[];
ROI_new=sortrows(ROI,4);
for i = 1:length(filelist_C1)
    [~,~,Red_Data(:,end+1)]=dataaquisition_new(ROI_new,filelist_C1{i},9999);
end
    
for i = 1:length(filelist_C2)
    [~,~,Green_Data(:,end+1)]=dataaquisition_new(ROI_new,filelist_C2{i},9999);
end

RBG_data=Red_Data./Green_Data;
deltaRBG_data=RBG_data(:,2:end)-RBG_data(:,1:end-1);

save(file_path(4:end),'Red_Data','Green_Data','RBG_data','deltaRBG_data');

