clear;close all;
kick_0=1;%1��ʱ��ȥ0������1��ʱ��ȥ0

file_path = uigetdir('','Select data path'); 
addpath(genpath(file_path));
cd(file_path);
ROI_list = dir([file_path '\*.mat']);
ROI_list=struct2cell(ROI_list);
ROI_list=ROI_list(1,:);
load(ROI_list{1});
filelist = dir([file_path '\*.tif']);
filelist=struct2cell(filelist);
filelist=filelist(1,:);
trial_number=length(filelist);

ROI_new=sortrows(ROI,4);
ROI_new=round(ROI_new);
Data=[];
for i = 1:length(filelist)
    [Data_pause]=dataaquisition(ROI_new,filelist{i});
    Data(:,end+1)=Data_pause(:,1);
    display(['  ��' num2str(i) '��']);
end

save([file_path '\data_final.mat'],'Data');

