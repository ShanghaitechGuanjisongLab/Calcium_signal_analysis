path_new = uigetdir('','Select data path');
cd(path_new);
base_path = uigetdir('','Select base path');

note_1 = 0;
Z_num = 1;
cd(base_path);
InfoImage = imfinfo('1.tif');
mImage = InfoImage(1).Width;
nImage = InfoImage(1).Height;
img_base = zeros(nImage,mImage,Z_num,'uint16');
for k = 1:Z_num
    fname = [num2str(k) '.tif'];
    img_base(:,:,k)=imread(fname,'Index',1);
end

filelist_new = dir([path_new '\*.tif']);
filelist_new=struct2cell(filelist_new);
filelist_new=filelist_new(1,:);
cd(path_new);

ii = 1;
for fi = 1:length(filelist_new)
    if note_1 == 0
        img_base_i = img_base(:,:,ii);
        [mean_img,std_img,bias]=Fun_main_lky_try(filelist_new{fi},img_base_i,fi);
    else
        [mean_img,std_img,bias]=Fun_main(filelist_new{fi},path_new,fi);
    end
    toc;
    tic;
    fprintf('_');
    %%
    if fi == 1
        max_mean_img=mean_img;
        max_std_img=std_img;
    else
        max_mean_img=max_mean_img+mean_img;
        max_std_img=max_std_img+std_img;
    end
    %%
    if fi == 1
        bias_sum=bias;
    else
        bias_sum(:,:,end+1)=bias;
    end

end
fprintf('\n');
max_std_img=max_std_img/length(filelist_new);
max_mean_img=max_mean_img/length(filelist_new);
max_std_img = uint16(max_std_img);
max_mean_img = uint16(max_mean_img);
imwrite(max_std_img,[path_new '\stable_Z_project\max_std.tif'],'WriteMode','append');
imwrite(max_mean_img,[path_new '\stable_Z_project\max_mean.tif'],'WriteMode','append');
save('bias_sum.mat','bias_sum','-v7.3');%