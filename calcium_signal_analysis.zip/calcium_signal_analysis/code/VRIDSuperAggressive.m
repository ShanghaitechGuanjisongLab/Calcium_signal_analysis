function [RegisteredImage,TranslateX,TranslateY] = VRIDSuperAggressive(MovingImage,FixedImage)
arguments
	MovingImage(:,:)uint16
	FixedImage(:,:)uint16
end
persistent optimizer metric
if isempty(optimizer)
	[optimizer, metric] = imregconfig('monomodal');
    %越小越容易飞
	optimizer.RelaxationFactor = 0.5;%步长缩短系数，默认0.5
	optimizer.MaximumIterations = 1;%最大迭代次数，默认100
    %越大越容易飞
	optimizer.GradientMagnitudeTolerance = 1;%平台期判定阈值，默认0.0001
	optimizer.MinimumStepLength = 1;%，最小步长，默认0.00001
	optimizer.MaximumStepLength = 1;%最大步长，默认0.0625
end
fixedRefObj = imref2d(size(FixedImage));
movingRefObj = imref2d(size(MovingImage));
initTform = affine2d();
initTform.T(3,1:2) = [mean(fixedRefObj.XWorldLimits) - mean(movingRefObj.XWorldLimits), mean(fixedRefObj.YWorldLimits) - mean(movingRefObj.YWorldLimits)];
Transformation = imregtform(MovingImage,movingRefObj,FixedImage,fixedRefObj,'translation',optimizer,metric,'PyramidLevels',3,'InitialTransformation',initTform);
RegisteredImage = imwarp(MovingImage, movingRefObj, Transformation,"nearest", 'OutputView', fixedRefObj, 'SmoothEdges', true);
TMatrix=Transformation.T;
TranslateX=TMatrix(3,1);
TranslateY=TMatrix(3,2);
end