%拉伸
main_path = 'D:\code';
cd(main_path);
kk = 0;
file_path_list = [];
Z_num_list = [];
note_1_list =[];
base_path_list = [];
for kmain = 1:100
    file_path_list(kmain).d = uigetdir('','Select data path');
    cd(file_path_list(kmain).d);
    Z_num_list(kmain).d = input('Enter number of piezo Z number :\n');
    note_1_list(kmain).d = input('Is this the first day data? 1:yes, 0:no.');
    if note_1_list(kmain).d == 0
        base_path_list(kmain).d = uigetdir('','Select base path');
    else
        base_path_list(kmain).d = 0;
    end
    note_2 = input('Is this the end data? 1:yes, 0:no.');
    if note_2 == 1
        kk = kmain;
        break;
    end
end
save path file_path_list Z_num_list note_1_list base_path_list
for kmain = 1:kk
    fprintf(['The ' num2str(kmain) 'th file start.' '\n']);
    clearvars -except kk kmain file_path_list Z_num_list note_1_list base_path_list
    file_path = file_path_list(kmain).d;
    show_file_path = file_path;
    show_file_path(show_file_path == '\') = '/';
    fprintf([show_file_path '\n']);
    Z_num = Z_num_list(kmain).d;
    note_1 = note_1_list(kmain).d;
    base_path = base_path_list(kmain).d;
    auto_multi_trans;
end