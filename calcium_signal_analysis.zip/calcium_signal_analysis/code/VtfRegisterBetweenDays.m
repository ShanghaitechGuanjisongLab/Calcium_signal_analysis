function [RegisteredImage,Transformation] = VtfRegisterBetweenDays(Moving,Fixed,TransformType)
arguments
	Moving(:,:)uint16
	Fixed(:,:)uint16
    TransformType(:,:)string{mustBeMember(TransformType,["similarity" "affine" "rigid" "translation"])}="affine"
end
persistent optimizer metric
if isempty(optimizer)
	[optimizer, metric] = imregconfig('multimodal');
	metric.NumberOfSpatialSamples = 500;
	metric.NumberOfHistogramBins = 50;
	metric.UseAllPixels = true;
	optimizer.GrowthFactor = 1.050000;
	optimizer.Epsilon = 1.50000e-06;
	optimizer.InitialRadius = 6.25000e-03;
	optimizer.MaximumIterations = 100;
end
fixedRefObj = imref2d(size(Fixed));
movingRefObj = imref2d(size(Moving));
initTform = affine2d();
initTform.T(3,1:2) = [mean(fixedRefObj.XWorldLimits) - mean(movingRefObj.XWorldLimits), mean(fixedRefObj.YWorldLimits) - mean(movingRefObj.YWorldLimits)];
Transformation = imregtform(Moving,movingRefObj,Fixed,fixedRefObj,TransformType,optimizer,metric,'PyramidLevels',3);
RegisteredImage = imwarp(Moving, movingRefObj, Transformation, 'OutputView', fixedRefObj, 'SmoothEdges', true);
end

