%修改第二行，然后运行即可
clear;
knum = 0;
data_set = [];
for kmain = 1:100
	for r = 1:10
		fprintf('Please input the data name.\n');
		fprintf('The format is as follows:''date_mouse_operation_region''. example: 20201201_LVIP1_postCNO_Z1)\n');
		data_name = input('data_name = ','s');
		for k = 1:10
			try
				fprintf('Please input the stimuli type and type_no\n');
				fprintf('Note: the same as Line 6 and Line 7 of E:/LKY/ana_data/name_write.m\n');
				type1 = input('tag(1).type = ','s');
				t_no1 = input('tag(1).t_no = ','s');
				eval(['tag(1).type = ' type1]);
				eval(['tag(1).t_no = ' t_no1]);
				if numel(tag(1).type) ~= numel(tag(1).t_no)
                    
					fprintf('The number of type should be the same as the number of t_no\n');
					a = iamwrong(1);
				end
				break;
			catch
				fprintf('Failed to save. Please try again. Or ask LKY for help. \n');
			end
		end
		[name] = tag_name_get(tag);
		[tag_file_name,tag_path] = uigetfile('*.mat','Select tag data: *.mat');
		ntp = numel(tag_path);
		note_num = 0;
		for k = ntp:-1:1
			if strcmp(tag_path(k),'\')
				note_num = note_num + 1;
			end
			if note_num == 2
				k1 = k;
				break;
			end
		end
		data_path = tag_path(1:k1);
		cd(data_path);
		[roi_file_name,roi_path] = uigetfile('*.zip','Select RoiSet*.zip');
		tif_path = uigetdir('','select tif path');
		note = input('note(more information, any format):','s');
		fprintf(['                               ' data_name]);
		fprintf('\n');
		Tag_fullfile = fullfile(tag_path,tag_file_name);
		RoiSetPath = fullfile(roi_path,roi_file_name);
		fprintf('#############################################\n');
        fprintf('Please check path. Are you ready? (Press any key to continue...)\n');
		fprintf('data_name = ');disp(data_name);
		fprintf('tag(1).type = ');disp(type1);
		fprintf('tag(1).t_no = ');disp(t_no1);
		fprintf('tag name is as follows \n');
		disp(name);
		fprintf('Tag:');disp(Tag_fullfile);
		fprintf('ROI:');disp(RoiSetPath);
		fprintf('Tif path:');disp(tif_path);
		fprintf(['note:' note '\n']);
        fprintf('#############################################\n');
		data_end = input('Are you sure?(1:Yes. 0:No.)');
		if data_end == 1
			data_set(kmain).data_name = data_name;
			data_set(kmain).tag = tag;
			data_set(kmain).name = name;
			data_set(kmain).Tag_fullfile = Tag_fullfile;
			data_set(kmain).RoiSetPath = RoiSetPath;
			data_set(kmain).tif_path = tif_path;
			data_set(kmain).note = note;
			break;
		end
	end
	kmain_end = input('Is this the end data? 1:yes, 0:no.');
    if kmain_end == 1
        knum = kmain;
        break;
    end
end
for kmain = 1:knum
    fprintf(['The ' num2str(kmain) 'th file start.' '\n']);
    clearvars -except kk kmain data_set
    data_name = data_set(kmain).data_name;
	disp(data_name);
	tag = data_set(kmain).tag;
	name = data_set(kmain).name;
	Tag_fullfile = data_set(kmain).Tag_fullfile;
	RoiSetPath = data_set(kmain).RoiSetPath;
	tif_path = data_set(kmain).tif_path;
	note = data_set(kmain).note;
    Fun_measure_adjust;
end