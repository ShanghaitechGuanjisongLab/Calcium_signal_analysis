NoSamples = 10*fps+1;
% Score1 = [];
Dataset = [];

for r = 1:max(BlockGroups)
%     Score1{r} = [];
    
    r1 = find(BlockGroups == r_list(r));
    Dataset{r} = [];
    topn = 1000;
    for k = 1:numel(r1)
        d1 = DataTable.Measurements{r1(k)}{1}(:,:,:);
        topn = min(topn,size(d1,3));
        d2 = zeros(size(d1,1),NoSamples,topn);
        for s = 1:topn
            s1 = d1(:,:,s);
            s2 = imresize(s1,[size(s1,1),NoSamples]);
            d2(:,:,s) = s2;
        end
        if k == 1
            Dataset{r} = d2;
        else
            Dataset{r} = Dataset{r}(:,:,1:topn);
            Dataset{r}(end+1:end+size(d2,1),:,:) = d2;
        end
    end
end

min_num = 10^10;
for r = 1:max(BlockGroups)
    if min_num > size(Dataset{r},3)
        min_num = size(Dataset{r},3);
    end
end
min_num = min_num - 1;