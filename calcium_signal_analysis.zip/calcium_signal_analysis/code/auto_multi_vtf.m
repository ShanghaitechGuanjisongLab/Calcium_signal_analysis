% %%This Program correct the scanline shift, the XY shift and the rotation shift. 

try
	load('E:\LKY\GPU_marker\GPU_marker.mat');
	if GPU_marker == 1
		fprintf(['Warning! GPU is using!\n']);
	end
	GPU_marker = 1;
	save('E:\LKY\GPU_marker\GPU_marker.mat','GPU_marker');
catch
	GPU_marker = 1;
	save('E:\LKY\GPU_marker\GPU_marker.mat','GPU_marker');
end

% addpath(genpath(file_path));
cd(file_path);
filelist = dir([file_path '\*.tif']);

filelist=struct2cell(filelist);
filelist=filelist(1,:);
trial_number=length(filelist);


if note_1 == 0
    cd(base_path);
    InfoImage = imfinfo('1.tif');
    mImage = InfoImage(1).Width;
    nImage = InfoImage(1).Height;
    img_base = zeros(nImage,mImage,Z_num,'uint16');
    for k = 1:Z_num
        fname = [num2str(k) '.tif'];
        img_base(:,:,k)=imread(fname,'Index',1);
    end
end
cd(file_path);

%%
% if Z_num > 1
tic;
    for fi = 1:trial_number
        fprintf([filelist{fi} '\n']);
        if ismember(1,note_3)
            tag=Fun_pre_tag_first(filelist{fi},Z_num,file_path,fi);
        else
            tag=Fun_pre(filelist{fi},Z_num,file_path,fi);
        end
        toc;
        tic;
        fprintf('_');
        if fi == 1
            tag_sum=tag;
        else
            xt1 = size(tag_sum);
            xt2 = size(tag);
            if xt1(1) ~= xt2(1) || xt1(2) ~= xt2(2)
                fprintf(['size_error','\n']);
                txt1 = ['Please check block' num2str(fi - 1) 'and block' num2str(fi)];
                fprintf(txt1);
            end
            tag_sum(:,:,end+1)=tag;
        end
    end
    save([file_path '\tag\tag_sum'],'tag_sum');
toc;
%%
tic;
for ii = 1 : Z_num
    path_new=[file_path '\Z' num2str(ii) ];
    filelist_new = dir([path_new '\*.tif']);
    filelist_new=struct2cell(filelist_new);
    filelist_new=filelist_new(1,:);
    cd(path_new);

    if note_1 == 1
		img_base_i = Fun_main_lky_get_base(filelist_new{1});
    end
    for fi = 1:length(filelist_new)
        fprintf(['\n(' num2str(fi) '/' num2str(length(filelist_new)) ') ' filelist_new{fi}]);
		fprintf('\n');
        if note_1 == 0
            img_base_i = img_base(:,:,ii);
			%Fun_main_vtf4
            [mean_img,std_img,bias,corrResults]=Fun_main_vtf4(filelist_new{fi},img_base_i,fi);
		else
			%Fun_main_vtf4
            [mean_img,std_img,bias,corrResults]=Fun_main_vtf4(filelist_new{fi},img_base_i,fi);
%             [mean_img,std_img,bias]=Fun_main(filelist_new{fi},path_new,fi);before20201026
        end
        toc;
        tic;
        fprintf('_');
        %%
        if fi == 1
            max_mean_img=mean_img;
            max_std_img=std_img;
        else
            max_mean_img=max_mean_img+mean_img;
            max_std_img=max_std_img+std_img;
        end
        %%
        if fi == 1
            bias_sum=bias;
            fcorr = corrResults;
        else
            bias_sum(:,:,end+1)=bias;
            fcorr(end+1,:) = corrResults;
        end

    end
    fprintf('\n');
    max_std_img=max_std_img/length(filelist_new);
    max_mean_img=max_mean_img/length(filelist_new);
    imwrite(max_std_img,[path_new '\stable_Z_project\max_std.tif'],'WriteMode','append');
    imwrite(max_mean_img,[path_new '\stable_Z_project\max_mean.tif'],'WriteMode','append');
    save('bias_sum.mat','bias_sum','fcorr','-v7.3');%
end
% else
%         for fi = 1:length(filelist)
%             Fun_main(filelist{fi});
%         end
% end
toc;

GPU_marker = 0;
save('E:\LKY\GPU_marker\GPU_marker.mat','GPU_marker');

fprintf(['\n' 'Congradulations!!!' '\n']);
fprintf(['Finished.' '\n']);
fprintf(['Thanks for Guan lab WangGuangyu.' '\n']);
fprintf(['Thanks for Guan lab LKY.' '\n']);
fprintf(['Thanks for Guan lab VTF.' '\n']);
