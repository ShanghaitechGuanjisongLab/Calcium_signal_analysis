CaDM20=CaAnalyze.CollectData.Rdc2_CaDM20;
LineColors=[240 0 0
            0 240 0
            0 0 240
            50 50 50]/255;
PointColors=[0 1/2 1
             1 1 0
             1 0 0];
CaDM20=sortrows(CaDM20,["Mouse","Date"]);
Mice=unique(CaDM20.Mouse);
NoMice=numel(Mice);
Pre=cell(NoMice,1);
for M=1:NoMice
	Dates=CaDM20.Date(CaDM20.Mouse==Mice(M));
    Pre{M}=Dates==min(Dates);
end
CaDM20.Pre=vertcat(Pre{:});
chosen_label1 = ["Yellow-air" "Blue-air-close" "Blue-audio-all" "Blue"];
% chosen_label1 = ["Blue"];
DataTable=CaDM20(ismember(CaDM20.Block,chosen_label1)&CaDM20.Pre,:);
% DataTable=CaDM20(ismember(CaDM20.Block,chosen_label1)&CaDM20.Learned|ismember(CaDM20.Block,chosen_label2)&~CaDM20.Learned,:);

% DataTable.Block(DataTable.Block=="Yellow-air"&DataTable.Pre)="Assoc.first";
% 
% DataTable.Block(DataTable.Block=="Blue-air-close"&DataTable.Pre)="Assoc.mid";
% DataTable.Block(DataTable.Block=="Blue-audio-all"&DataTable.Pre)="Assoc.last";
% DataTable.Block(DataTable.Block=="Blue"&DataTable.Pre)="Cue";

% DataTable.Block(DataTable.Block=="Blue-audio-new"&DataTable.Pre)="Blue-audio";
% DataTable.Block(DataTable.Block=="Yellow-air"&DataTable.Pre)="Blue-air-first";
% DataTable.Block(DataTable.Block=="Yellow"&DataTable.Pre)="Cue.(a.A.)";
% DataTable.Block(DataTable.Block=="Blue-close"&DataTable.Pre)="Cue.(a.A.)-first";

%DataTable.Block(DataTable.Pre)=DataTable.Block(DataTable.Pre)+".learnt";
show_button = 1;
fps = 8;
title_name = 'layer2';
axis_rank = [3 1 2];
highlight_time_window = [0 0.5];
show_time_window = [0 8];
PCAshow_fig(DataTable, LineColors, PointColors, title_name, show_button, fps, highlight_time_window, show_time_window, axis_rank);
%% 
% view_point = [69.26 3.96];
%% 
% view_point = [189.26 3.96];
%%
view_point = [309.26 3.96];


%%
view(view_point);
axis1 = axis;
Pointbutton = 1;
[Data, BlockGroups, NoSamples, Coeff, Explained, Score, mu] = PCAshow_fig_subtime(DataTable, LineColors, title_name, Pointbutton, show_button, fps, axis1, view_point, axis_rank, highlight_time_window, show_time_window);
view(view_point);
a = axis;
% xticks([-1 0 1]);
% yticks([-1 0 1 5]);
% zticks([-1 0 1]);

r_list = [1 2 3];
show_time_window = [0 8];
[Score2, NoCells] = PCAshow_fig2(DataTable, Coeff, mu, fps, show_time_window);
Pointbutton = 1;
Score2 = Scoreto0(Score2);
[NoSamples, BlockGroups, Score] = PCAshow_fig_subtime2_r(DataTable, Score2, Explained, LineColors, title_name, fps, Pointbutton, show_button);

r_list = [1 2 3 4 5 6];
