function [path,neurons] = read_tif(neurons,cell_edgex,cell_edgey)
path = uigetdir('','select tif path');
files = dir([path '\*.tif']);

%file_path = 'C:\Users\91879\OneDrive\Documents\Code\Matlab\Read_Data_from_ImageJ_ROI\data\Z1_02_air.tif';
for i_file = 1:length(files)
    tic;
    TifLink = Tiff(fullfile(path,files(i_file).name), 'r');
    show_fname = fullfile(path,files(i_file).name);
    show_fname(show_fname == '\') = '/';
    fprintf([show_fname '\n']);
    im_info = imfinfo(fullfile(path,files(i_file).name));
    frame = length(im_info);
    height = im_info(1).Height;
    width = im_info(1).Width;

%     disp(i_file);

    for i_frame=1:frame
        TifLink.setDirectory(i_frame);
        imData = TifLink.read();

        for i_neuron = 1 :size(neurons,2) 
            coordinate = neurons(i_neuron).cor;
            signals = diag(imData(coordinate(:,1),coordinate(:,2)));
            neurons(i_neuron).trial(i_file).signal(i_frame) = mean(signals);
        end
        
        if i_frame == 1
            figure('position',[300,300,512,512]);
            a = double(imData);
            show_bar = [min(min(a)) max(max(a))];
            imagesc(a);colormap gray;caxis(show_bar);
            hold on;
            axis([0 513 0 513]);
            fname = files(i_file).name;
            fname(fname == '_') = ' ';
            title(fname);
            plot(cell_edgex,cell_edgey,'w');
        end

    end
    TifLink.close();
    
    toc;
    
    
end
