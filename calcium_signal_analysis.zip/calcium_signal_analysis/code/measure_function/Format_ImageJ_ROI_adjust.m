function [path,neurons,cell_edgex,cell_edgey,measure_data] = Format_ImageJ_ROI_adjust()
max_width = 512;
max_height = 512;

[roi_file_name,roi_path] = uigetfile('*.zip','Select RoiSet*.zip');
RoiSetPath = fullfile(roi_path,roi_file_name);

RoiPaths = unzip(RoiSetPath);
NoRois=numel(RoiPaths);
[xs,ys,as,bs]=deal(zeros(NoRois,1));
for a=1:NoRois
    Fid=fopen(RoiPaths{a},"r","b");
    fseek(Fid,8,"bof");
    ys(a)=fread(Fid,1,"int16");
    xs(a)=fread(Fid,1,"int16");
    ye=fread(Fid,1,"int16");
    xe=fread(Fid,1,"int16");
    fclose(Fid);
    as(a)=xe-xs(a);
    bs(a)=ye-ys(a);
end
delete(RoiPaths{:});
neurons = [];

%%%背景大小
base_d = 20;

%%%细胞边界
ma = max(as);
nc = numel(xs);
cell_edgex = zeros(2*ma+1,nc);
cell_edgey = zeros(2*ma+1,nc);

% poolsize_chosen = 4;
% poolobj = gcp('nocreate'); % If no pool, do not create new one.
% if isempty(poolobj)||poolobj.NumWorkers<poolsize_chosen
% 	delete(poolobj);
% 	parpool(poolsize_chosen);
% end

for i_pixel = 1:numel(xs)
    x0=xs(i_pixel);
    y0=ys(i_pixel);
    a=as(i_pixel);
    b=bs(i_pixel);
    x1 = x0 + 1/2;
    y1 = y0 + 1/2;
    y2 = y1 + 1/2 + b/2;
    xmi = x1;
    xma = xmi + a;
    %%%细胞边界-展示用
    xx1 = xmi:xma - 1;
    xx2 = xma:-1:xmi + 1;
    xx3 = 1:2*ma - 2*a;
    xx3 = 0*xx3 + xmi;
    xx4 = xmi;
    yy1 = y1 + b/2 + ((b/2)^2 - ((xx1 - (xmi + xma)/2)/a*b).^2).^(1/2);
    yy2 = y1 + b/2 - ((b/2)^2 - ((xx2 - (xmi + xma)/2)/a*b).^2).^(1/2);
    yy3 = 0*xx3 + y1 + b/2;
    yy4 = y1 + b/2;
    xxa = [xx1 xx2 xx3 xx4]';
    yya = [yy1 yy2 yy3 yy4]';
    cell_edgex(:,i_pixel) = xxa;
    cell_edgey(:,i_pixel) = yya;
    %%%细胞像素
	neurons(i_pixel).cor = zeros(512,512);
	for ix = xmi+1/2:xma-1/2
		if ix >= 1 && ix <= max_width
			d = sqrt((b/2)^2-b^2/a^2*(ix - (xmi+xma)/2)^2);
			ymin = round(y2-d);
			ymax = round(y2+d) - 1;
            if ymin < 1
				ymin = 1;
            end
            if ymax > max_height
				ymax = max_height;
            end
            neurons(i_pixel).cor(ymin:ymax,ix) = 1;
		else
			fprintf('Warning! Part of the cell is out of the figure.');
		end
    end
    neurons(i_pixel).cor = reshape(neurons(i_pixel).cor,1,512*512);
    neurons(i_pixel).nsg = sum(neurons(i_pixel).cor);
	
	%%%bas像素
	neurons(i_pixel).bas_cor = zeros(512,512);
	xmi1 = xmi-base_d;
	xma1 = xma+base_d;
	b1 = b+2*base_d;
	a1 = a+2*base_d;
	for ix = xmi1+1/2:xma1-1/2
		if ix >= 1 && ix <= max_width
			d1 = sqrt((b1/2)^2-b1^2/a1^2*(ix - (xmi1+xma1)/2)^2);
			ymin = round(y2-d1);
			ymax = round(y2+d1) - 1;
            if ymin < 1
				ymin = 1;
            end
            if ymax > max_height
				ymax = max_height;
            end
            neurons(i_pixel).bas_cor(ymin:ymax,ix) = 1;
		end
    end
    neurons(i_pixel).bas_cor = reshape(neurons(i_pixel).bas_cor,1,512*512);
	neurons(i_pixel).bas_cor = neurons(i_pixel).bas_cor - neurons(i_pixel).cor;
    neurons(i_pixel).nbsg = sum(neurons(i_pixel).bas_cor);
end




disp('ROI format completed');
[path,neurons] = read_tif_adjust(neurons,cell_edgex,cell_edgey);
tic;
[measure_data] = data_format(neurons);
toc;
end


