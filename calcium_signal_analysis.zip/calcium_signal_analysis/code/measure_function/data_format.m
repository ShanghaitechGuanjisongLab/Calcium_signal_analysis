function [measure_data] = data_format(neurons)
neuron_no = length(neurons);
trial_no = length(neurons(1).trial);
frame_no = length(neurons(1).trial(1).signal);
equal_frame = 1;
for k = 1:numel(neurons(1).trial)
    frame_nok = numel(neurons(1).trial(k).signal);
    if frame_nok ~= frame_no
        equal_frame = 0;
        break;
    end
end

save_name = 'test';
measure_data = [];
if equal_frame == 1
    for i_neuron = 1:length(neurons)
        for i_trial = 1:trial_no
            for i_frame = 1:frame_no
               measure_data(i_frame,i_neuron,i_trial) = neurons(i_neuron).trial(i_trial).signal(i_frame);
            end
        end
    end
else
    for i_trial = 1:trial_no
        measure_data_sub = [];
        for i_neuron = 1:length(neurons)
            for i_frame = 1:numel(neurons(1).trial(i_trial).signal)
               measure_data_sub(i_frame,i_neuron) = neurons(i_neuron).trial(i_trial).signal(i_frame);
            end
        end
        measure_data{i_trial} = measure_data_sub;
    end
end

eval([save_name ' = measure_data;']);
clear except data



