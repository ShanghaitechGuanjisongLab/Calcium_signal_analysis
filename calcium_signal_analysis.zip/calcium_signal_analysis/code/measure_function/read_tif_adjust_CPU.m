function [path,neurons] = read_tif_adjust_CPU(neurons,cell_edgex,cell_edgey)
path = uigetdir('','select tif path');
files = dir([path '\*.tif']);

%file_path = 'C:\Users\91879\OneDrive\Documents\Code\Matlab\Read_Data_from_ImageJ_ROI\data\Z1_02_air.tif';
im_info = imfinfo(fullfile(path,files(1).name));
frame = length(im_info);
height = im_info(1).Height;
width = im_info(1).Width;
for i_file = 1:length(files)
    tic;
    show_fname = fullfile(path,files(i_file).name);
    show_fname(show_fname == '\') = '/';
    fprintf([show_fname '\n']);
	temp_tif = zeros(height,width,frame);
	ReadClient=Tiff(fullfile(path,files(i_file).name));
	for a = 1:frame
		if mod(a,100) == 0
			fprintf('_');
		end
        temp_tif(:,:,a)=ReadClient.read;
		if ReadClient.lastDirectory
			ReadClient.close;
			break;
		end
		ReadClient.nextDirectory;
	end
	show_tif = temp_tif(:,:,1);
    temp_tif = reshape(temp_tif,height*width,frame);
	mean_temp_tif = mean(temp_tif');
    raw_neurons = zeros(size(neurons,2),frame);
	bas_neurons = zeros(size(neurons,2),frame);
% 	temp_tif2 = gpuArray(uint16(temp_tif));
	temp_tif2 = temp_tif;
	clearvars temp_tif;
	for i_neuron = 1:size(neurons,2)
		
		%bas减半
		mean_base = neurons(i_neuron).bas_cor.*mean_temp_tif;
		mean_base_plus = mean_base(mean_base > 0);
		mid_mean_base = median(mean_base_plus);
		bas_min_mid = mean_base < mid_mean_base;
		bas_cor = neurons(i_neuron).bas_cor.*bas_min_mid;
        bas_value = temp_tif2(logical(bas_cor),:);
% 		bas_value = gather(bas_value);
		bas_neurons(i_neuron,:) = sum(bas_value);
		%cell减半
% 		mean_cell = neurons(i_neuron).cor.*mean_temp_tif;
% 		mean_cell_plus = mean_cell(mean_cell > 0);
% 		mid_mean_cell = median(mean_cell_plus);
% 		cell_max_mid = mean_cell > mid_mean_cell;
% 		cor = neurons(i_neuron).cor.*cell_max_mid;
% 		raw_neurons(i_neuron,:) = cor*temp_tif;
		neuron_cor = neurons(i_neuron).cor;
		raw_value = temp_tif2(logical(neuron_cor),:);
% 		raw_value = gather(raw_value);
		raw_neurons(i_neuron,:) = sum(raw_value);
		%
% 		raw_neurons(i_neuron,:) = neurons(i_neuron).cor*temp_tif;
%       all_neurons(i_neuron,:) = neurons(i_neuron).bas_cor*temp_tif;
	end
	clearvars temp_tif2;
	fprintf('\n');
	
	%减半
	if i_file == 1
		for i_neuron = 1:size(neurons,2)
			neurons(i_neuron).nbsg = neurons(i_neuron).nbsg/2;
% 			neurons(i_neuron).nsg = neurons(i_neuron).nsg/2;
		end
	end
	
	%
    for i_neuron = 1:size(neurons,2)
		rs1 = raw_neurons(i_neuron,:);
		bs1 = bas_neurons(i_neuron,:);
		ns = neurons(i_neuron).nsg;
		nbs = neurons(i_neuron).nbsg;
		mbs = mean(bs1/nbs);
		s1 = rs1/ns - bs1/nbs + mbs;
		neurons(i_neuron).trial(i_file).signal = s1;
    end
    
    %%%展示细胞
    figure('position',[300,300,height,width]);
    a = double(show_tif);
    show_bar = [min(min(a)) max(max(a))];
    imagesc(a);colormap gray;caxis(show_bar);
    hold on;
    axis([0 height+1 0 width+1]);
    fname = files(i_file).name;
    fname(fname == '_') = ' ';
    title(fname);
    plot(cell_edgex,cell_edgey,'w');
    toc;
end
