function [RegisteredImage,TranslateX,TranslateY] = VtfRegisterInDay3(MOVING,GaussedFixed,FixedRefObj)
arguments
	MOVING(:,:)uint16
	GaussedFixed(:,:)uint16
	FixedRefObj(1,1)imref2d
end
persistent initTform optimizer metric
if isempty(initTform)
	initTform=affine2d();
	[optimizer, metric] = imregconfig('monomodal');
	%越小越容易飞
	optimizer.RelaxationFactor = 0.2;%步长缩短系数，默认0.5
	optimizer.MaximumIterations = 20;%最大迭代次数，默认100
	%越大越容易飞
	optimizer.GradientMagnitudeTolerance = 3;%平台期判定阈值，默认0.0001
	optimizer.MinimumStepLength = 0.02;%，最小步长，默认0.00001
	optimizer.MaximumStepLength = 0.7;%最大步长，默认0.0625
end
movingRefObj = imref2d(size(MOVING));

% Align centers
Transformation = imregtform(imgaussfilt(MOVING,1),movingRefObj,GaussedFixed,FixedRefObj,'translation',optimizer,metric);
RegisteredImage = imwarp(MOVING, movingRefObj, Transformation,"nearest", 'OutputView', FixedRefObj);
TMatrix=Transformation.T;
TranslateX=TMatrix(3,1);
TranslateY=TMatrix(3,2);
end