% %%This Program correct the scanline shift, the XY shift and the rotation shift. 


% addpath(genpath(file_path));
cd(file_path);
filelist = dir([file_path '\*.tif']);

filelist=struct2cell(filelist);
filelist=filelist(1,:);
trial_number=length(filelist);


if note_1 == 0
    cd(base_path);
    InfoImage = imfinfo('1.tif');
    mImage = InfoImage(1).Width;
    nImage = InfoImage(1).Height;
    img_base = zeros(nImage,mImage,Z_num,'uint16');
    for k = 1:Z_num
        fname = [num2str(k) '.tif'];
        img_base(:,:,k)=imread(fname,'Index',1);
    end
end
cd(file_path);

%%
tic;
path_new = file_path;
filelist_new = dir([path_new '\*.tif']);
filelist_new = struct2cell(filelist_new);
filelist_new = filelist_new(1,:);
cd(path_new);
for ii = 1 : Z_num
    switch note_1
        case 1
            img_base_i = Fun_main_lky_get_base(filelist_new{1});
        case 0
            img_base_i = img_base(:,:,ii);
    end
    for fi = 1:length(filelist_new)
        fprintf(['\n(' num2str(fi) '/' num2str(length(filelist_new)) ') ' filelist_new{fi} '\n']);
        [mean_img,std_img,bias,corrResults]=Fun_main_vtf8(filelist_new{fi},img_base_i,fi);%Fun_main_lky before 201127
        toc;
        tic;
        fprintf('_');
        %%
        if fi == 1
            max_mean_img=mean_img;
            max_std_img=std_img;
        else
            max_mean_img=max_mean_img+mean_img;
            max_std_img=max_std_img+std_img;
        end
        %%
        if fi == 1
			xb = size(bias,1);
			if xb > 1
	            bias_sum = bias;
	            fcorr = corrResults;
			else
				bias_sum = [];
				fcorr = [];
			end
        else
            bias_sum(:,:,end+1)=bias;
            fcorr(end+1,:) = corrResults;
        end

    end
    fprintf('\n');
    max_std_img=max_std_img/length(filelist_new);
    max_mean_img=max_mean_img/length(filelist_new);
    imwrite(max_std_img,[path_new '\stable_Z_project\max_std.tif'],'WriteMode','append');
    imwrite(max_mean_img,[path_new '\stable_Z_project\max_mean.tif'],'WriteMode','append');
    save('bias_sum.mat','bias_sum','fcorr','-v7.3');%

end
% else
%         for fi = 1:length(filelist)
%             Fun_main(filelist{fi});
%         end
% end
toc;


fprintf(['\n' 'Congradulations!!!' '\n']);
fprintf(['Finished.' '\n']);
fprintf(['Thanks for Guan lab WangGuangyu.' '\n']);
fprintf(['Thanks for Guan lab LKY.' '\n']);
fprintf(['Thanks for Guan lab VTF.' '\n']);
