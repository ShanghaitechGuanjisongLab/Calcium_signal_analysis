file_path = uigetdir('','Select data path');
filelist = dir([file_path]);
nf = numel(filelist);
folder_list = [];
nfl = 0;
for k = 1:nf
	if filelist(k).name(1) ~= '.'
		if filelist(k).isdir == 1
			nfl = nfl + 1;
			folder_list{nfl} = filelist(k).name;
		end
	end
end
for k = 1:nfl
	clearvars -except k nfl folder_list file_path
	path1 = [file_path '\' folder_list{k}];
	cd(path1);
	
	%%footnote name
	
	
	
end
