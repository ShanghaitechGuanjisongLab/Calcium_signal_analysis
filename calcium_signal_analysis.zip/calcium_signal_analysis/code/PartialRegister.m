function [Registered,XTranslate,YTranslate]=PartialRegister(Fixed,RefObj,Moving,Transformation,Displacement)
Registered=zeros(size(Moving));
NoFrames=size(Moving,3);
[XTranslate,YTranslate]=deal(zeros(NoFrames,1));
for a=1:NoFrames
	M=imwarp(Moving(:,:,a),RefObj, Transformation,"nearest", 'OutputView',RefObj);
	if nargin>4
		M=imwarp(M,Displacement,"nearest");
	end
    [Registered(:,:,a),XTranslate(a),YTranslate(a)]=Normxcorr2Register(M,Fixed,50);
end
end