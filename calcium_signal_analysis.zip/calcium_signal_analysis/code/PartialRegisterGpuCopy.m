function [Registered,XTranslate,YTranslate]=PartialRegisterGpuCopy(RefObj,Moving,Transformation,Displacement)
Registered=zeros(size(Moving));
NoFrames=size(Moving,3);
[XTranslate,YTranslate]=deal(zeros(NoFrames,1));
try
	for a=1:NoFrames
		M=imwarp(gpuArray(Moving(:,:,a)),RefObj, Transformation,"nearest", 'OutputView',RefObj);
		if nargin>4
			M=imwarp(M,Displacement, "nearest");
		end
		Registered(:,:,a) = M;
	end
catch
	for a=1:NoFrames
		M=imwarp(Moving(:,:,a),RefObj, Transformation,"nearest", 'OutputView',RefObj);
		if nargin>4
			M=imwarp(M,Displacement, "nearest");
		end
		Registered(:,:,a) = M;
	end
end
end