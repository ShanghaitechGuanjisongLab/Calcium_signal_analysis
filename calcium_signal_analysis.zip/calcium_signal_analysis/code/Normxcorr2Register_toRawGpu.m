function [RegisteredImage,TranslateX,TranslateY] = Normxcorr2Register_toRawGpu(MovingImage,FixedImage,MaxTranslationStep)
arguments
	MovingImage(:,:)
	FixedImage(:,:)
	MaxTranslationStep(1,1)double=50
end
RawImage = MovingImage;
MovingImage = fig_smooth(MovingImage);
C=gather(normxcorr2(MovingImage(MaxTranslationStep+1:end-MaxTranslationStep,MaxTranslationStep+1:end-MaxTranslationStep),FixedImage));
MovingImage=gather(MovingImage);
MiSize=size(MovingImage);
Mts2=MaxTranslationStep*2;
ImpossibleOffsets=MiSize-Mts2;
[~,MaxInd]=max(C(ImpossibleOffsets(1):ImpossibleOffsets(1)+Mts2-1,ImpossibleOffsets(2):ImpossibleOffsets(2)+Mts2-1),[],"all","linear");
[TranslateY,TranslateX]=ind2sub([Mts2 Mts2],MaxInd);
[TranslateY,TranslateX]=deal(TranslateY-MaxTranslationStep-1,TranslateX-MaxTranslationStep-1);
RegisteredImage=zeros(MiSize);
RegisteredImage(max(1,1+TranslateY):min(end,end+TranslateY),max(1,TranslateX+1):min(end,end+TranslateX))=RawImage(max(1,1-TranslateY):min(end,end-TranslateY),max(1,1-TranslateX):min(end,end-TranslateX));
end