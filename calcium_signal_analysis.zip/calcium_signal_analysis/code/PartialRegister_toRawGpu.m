function [Registered,XTranslate,YTranslate]=PartialRegister_toRawGpu(Fixed,RefObj,Moving,Transformation)
Registered=zeros(size(Moving));
NoFrames=size(Moving,3);
[XTranslate,YTranslate]=deal(zeros(NoFrames,1));
try
	for a=1:NoFrames
		[Registered(:,:,a),XTranslate(a),YTranslate(a)]=Normxcorr2Register_toRawGpu(imwarp(gpuArray(Moving(:,:,a)),RefObj, Transformation,"nearest", 'OutputView',RefObj),Fixed,50);
	end
catch
	for a=1:NoFrames
		[Registered(:,:,a),XTranslate(a),YTranslate(a)]=Normxcorr2Register_toRaw(imwarp(Moving(:,:,a),RefObj, Transformation,"nearest", 'OutputView',RefObj),gather(Fixed),50);
	end
end
end