main_path = 'D:\code';
cd(main_path);
rmdir('temp', 's');
mkdir('temp');
main_temp_path = 'D:\code\temp';
kk = 0;
file_path_list = [];
Z_num_list = [];
note_1_list =[];
base_path_list = [];
for k = 1:100
    file_path_list(k).d = uigetdir('','Select data path');
    cd(file_path_list(k).d);
    Z_num_list(k).d = input('Enter number of piezo Z number :\n');
    note_1_list(k).d = input('Is this the first day data? 1:yes, 0:no.');
    if note_1_list(k).d == 0
        base_path_list(k).d = uigetdir('','Select base path');
    else
        base_path_list(k).d = 0;
    end
    note_2 = input('Is this the end data? 1:yes, 0:no.');
    if note_2 == 1
        kk = k;
        break;
    end
end
cd(main_temp_path)
save path file_path_list Z_num_list note_1_list  base_path_list
for k = 1:kk
    fprintf(['The ' num2str(k) 'th file start.' '\n']);
    cd(main_temp_path)
    save main_data main_temp_path kk k
    clear all;
    load main_data
    load path
    file_path = file_path_list(k).d;
    show_file_path = file_path;
    show_file_path(show_file_path == '\') = '/';
    fprintf([show_file_path '\n']);
    Z_num = Z_num_list(k).d;
    note_1 = note_1_list(k).d;
    base_path = base_path_list(k).d;
    auto_multi;
end