%% MVGC Multivariate Granger Causality Toolbox - Release Notes
%
% (C) Lionel Barnett and Anil K. Seth, 2012. See file license.txt in
% installation directory for licensing terms.
%
%% v1.0 2012-10-09
%
% * Initial release
%
%%
