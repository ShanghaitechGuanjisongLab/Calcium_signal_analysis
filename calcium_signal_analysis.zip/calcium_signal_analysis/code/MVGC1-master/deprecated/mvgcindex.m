%% The MVGC Multivariate Granger Causality Toolbox
%
%% <mvgcrelnotes.html Release notes>
%
%% <mvgchelp.html Overview>
%
%% <matlab:open('mvgc_doc.pdf') Reference document>
%
%% <mvgcfuncref.html Function reference>
%
%%
%
% [(C)] _Lionel Barnett and Anil K. Seth, 2012. See file
% <matlab:open('license.txt') license.txt> in root directory for licensing
% terms._
%
%%
