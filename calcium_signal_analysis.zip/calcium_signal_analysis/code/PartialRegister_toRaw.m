function [Registered,XTranslate,YTranslate]=PartialRegister_toRaw(Fixed,RefObj,Moving,Transformation)
Registered=zeros(size(Moving));
NoFrames=size(Moving,3);
[XTranslate,YTranslate]=deal(zeros(NoFrames,1));
for a=1:NoFrames
    [Registered(:,:,a),XTranslate(a),YTranslate(a)]=Normxcorr2Register_toRaw(imwarp(Moving(:,:,a),RefObj, Transformation,"nearest", 'OutputView',RefObj),Fixed,50);
end
end