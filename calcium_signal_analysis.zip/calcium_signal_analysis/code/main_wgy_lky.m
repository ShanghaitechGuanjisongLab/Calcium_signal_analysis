% %%This Program correct the scanline shift, the XY shift and the rotation shift. 

file_path = uigetdir('','Select data path');
Z_num = input('Enter number of piezo Z number :\n');
addpath(genpath(file_path));
cd(file_path);
filelist = dir([file_path '\*.tif']);

filelist=struct2cell(filelist);
filelist=filelist(1,:);
trial_number=length(filelist);

note_1 = input('Is this the first data? 1:yes, 0:no.');
if note_1 == 0
    base_path = uigetdir('','Select base path');
    cd(base_path);
    InfoImage = imfinfo('1.tif');
    mImage = InfoImage(1).Width;
    nImage = InfoImage(1).Height;
    img_base = zeros(nImage,mImage,Z_num,'uint16');
    for k = 1:Z_num
        fname = [num2str(k) '.tif'];
        img_base(:,:,k)=imread(fname,'Index',1);
    end
end
cd(file_path);

%%
% if Z_num > 1
tic;
    for fi = 1:trial_number
        tag=Fun_pre(filelist{fi},Z_num,file_path,fi);
        toc;
        tic;
        fprintf('_');
        if fi == 1
            tag_sum=tag;
        else
            xt1 = size(tag_sum);
            xt2 = size(tag);
            if xt1(1) ~= xt2(1) || xt1(2) ~= xt2(2)
                fprintf(['size_error','\n']);
                txt1 = ['Please check block' num2str(fi - 1) 'and block' num2str(fi)];
                fprintf(txt1);
            end
            tag_sum(:,:,end+1)=tag;
        end
    end
    save([file_path '\tag\tag_sum'],'tag_sum');
toc;
%%
tic;
for ii = 1 : Z_num
    path_new=[file_path '\Z' num2str(ii) ];
    filelist_new = dir([path_new '\*.tif']);
    filelist_new=struct2cell(filelist_new);
    filelist_new=filelist_new(1,:);
    cd(path_new);


    for fi = 1:length(filelist_new)
        if note_1 == 0
            img_base_i = img_base(:,:,ii);
            [mean_img,std_img,bias]=Fun_main_lky(filelist_new{fi},img_base_i,fi);
        else
            [mean_img,std_img,bias]=Fun_main(filelist_new{fi});
        end
        toc;
        tic;
        fprintf('_');
        %%
        if fi == 1
            max_mean_img=mean_img;
            max_std_img=std_img;
        else
            max_mean_img=max_mean_img+mean_img;
            max_std_img=max_std_img+std_img;
        end
        %%
        if fi == 1
            bias_sum=bias;
        else
            bias_sum(:,:,end+1)=bias;
        end

    end
    fprintf('\n');
    max_std_img=max_std_img/length(filelist_new);
    max_mean_img=max_mean_img/length(filelist_new);
    imwrite(max_std_img,[path_new '\stable_Z_project\max_std.tif'],'WriteMode','append');
    imwrite(max_mean_img,[path_new '\stable_Z_project\max_mean.tif'],'WriteMode','append');
    save('bias_sum.mat','bias_sum','-v7.3');%

end
% else
%         for fi = 1:length(filelist)
%             Fun_main(filelist{fi});
%         end
% end
toc;


fprintf(['\n' 'Congradulations!!!' '\n']);
fprintf(['Finished.' '\n']);
fprintf(['Thanks for Guan lab WangGuangyu.' '\n']);
