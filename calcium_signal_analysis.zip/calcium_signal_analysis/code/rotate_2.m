%bΪ�����aΪԭʼ���ݣ�xΪx�����ƶ���yΪy�����ƶ���rΪ��ʱ����ת�Ƕ�
%[bxs,bxe]Ϊb��x�����¼���䣬[bys,bye]ͬ��
function b = rotate_2(a,x,y,r,bxs,bxe,bys,bye)
[xa,ya] = size(a);
x0 = (.9 + xa)/2;
y0 = (.9 + ya)/2;
sinr = sin(r/180*pi);
cosr = cos(r/180*pi);
b = zeros(xa,ya);
for k = bxs:bxe
    for s = bys:bye
        %get b(k,r)
        x1 = k - x0;
        y1 = s - y0;
        rn = (x1^2 + y1^2).^(1/2);
        cosa = x1/rn;
        sina = y1/rn;
        x2 = rn*(cosa*cosr + sina*sinr) - x + x0;
        y2 = rn*(sina*cosr - cosa*sinr) - y + y0;
        ax1 = floor(x2);
        ax2 = ax1 + 1;
        ay1 = floor(y2);
        ay2 = ay1 + 1;
        if ax1 >= 1 && ax2 <= xa
            if ay1 >= 1 && ay2 <= ya
                u = x2 - ax1;
                v = y2 - ay1;
                %˫���Բ�ֵ
                %f(i+u,j+v) = (1-u)(1-v)f(i,j) + (1-u)vf(i,j+1) + u(1-v)f(i+1,j) + uvf(i+1,j+1)
                
%                 b(k,r) = (1 - u)*(1 - v)*a(ax1,ay1) + (1 - u)*v*a(ax1,ay2) + u*(1 - v)*a(ax2,ay1) + u*v*a(ax2,ay2);
                if u < 1/2
                    if v < 1/2
                        b(k,s) = a(ax1,ay1);
                    else
                        b(k,s) = a(ax1,ay2);
                    end
                else
                    if v < 1/2
                        b(k,s) = a(ax2,ay1);
                    else
                        b(k,s) = a(ax2,ay2);
                    end
                end
                
            end
        end
    end
end