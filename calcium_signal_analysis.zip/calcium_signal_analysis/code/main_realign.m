file_path = uigetdir('','Select data path'); 
addpath(genpath(file_path));
cd(file_path);
filelist = dir([file_path '\*.tif']);

filelist=struct2cell(filelist);
filelist=filelist(1,:);
trial_number=length(filelist);

for re_i=1:trial_number
            fname=filelist{re_i};
            [mean_img,std_img,bias]=Fun_main(fname,file_path,re_i);
            %%
            if re_i==1;
                max_mean_img=mean_img;
                max_std_img=std_img;
            else
                max_mean_img=max_mean_img+mean_img;
                max_std_img=max_std_img+std_img;
            end
            %%
            if re_i== 1;
                bias_sum=bias;
            else
                bias_sum(:,:,end+1)=bias;
            end
end
        max_std_img=max_std_img/trial_number;
        max_mean_img=max_mean_img/trial_number;
        imwrite(max_std_img,[file_path '\stable_Z_project\max_std.tif'],'WriteMode','append');
        imwrite(max_mean_img,[file_path '\stable_Z_project\max_mean.tif'],'WriteMode','append');
        save('bias_sum.mat','bias_sum','-v7.3');%
