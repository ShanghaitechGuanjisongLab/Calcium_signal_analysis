function A1 = fig_smooth(A,u)
arguments
	A
	u = [0 0 1 0 0
	 0 1 2 1 0
	 1 2 5 2 1
	 0 1 2 1 0
	 0 0 1 0 0]/21;
end
[xa,ya] = size(A);
A1 = zeros(xa + 4,ya + 4);

 
for k = 0:4
	for r = 0:4
		A1(1+k:xa+k,1+r:ya+r) = A1(1+k:xa+k,1+r:ya+r) + double(A)*u(k+1,r+1);
	end
end
A1 = round(A1(3:end - 2,3:end - 2));
% B = zeros(xa,ya,'uint16');
% B(:,:) = A1(:,:);