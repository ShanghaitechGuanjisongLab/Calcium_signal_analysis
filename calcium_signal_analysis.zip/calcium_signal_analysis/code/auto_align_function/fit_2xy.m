%aΪ������ͼ��bΪ��׼ͼ��
%cΪ������ͼ��cabΪ��ͼ������У׼�����ϵ����[xc,yc,rc]ΪУ������
%xmb,ymb,rmbΪx,y����ת��r�Ĳ���
%mb = aΪȡ����[-a,a],����Ĭ��
%mb = [a,b]Ϊȡ����[a,b],����Ĭ��
%mb = [a,b,s]Ϊȡ����[a,b],����Ϊs
function [c,cab,xc,yc,madcab] = fit_2xy(a,b,xmb,ymb)
[xa,ya] = size(a);
[xas,xae,xt] = fit_2_para(xmb,0.3);
[yas,yae,yt] = fit_2_para(ymb,0.3);

p1 = 1/8; %before 200522 1/4
xbs = floor(xa*p1) + 1;%the base of x: start point
xbe = floor(xa*(1 - p1)) + 1;%the base of x: end point
ybs = floor(ya*p1) + 1;
ybe = floor(ya*(1 - p1)) + 1;
b1 = b(xbs:xbe,ybs:ybe);
cab = 0;
xc = 0;
yc = 0;
d_cab = []; % data of corrcoef(a,b)
k1 = 0;
for k = xas:xt:xae
    k1 = k1 + 1;
    r1 = 0;
    for r = yas:yt:yae
        r1 = r1 + 1;
        try
            a1 = a(xbs+k:xbe+k,ybs+r:ybe+r);
        catch
            fprintf('bug');
            save('error.mat','k','r','xbs','xbe','ybs','ybe','xt','yt','a','b');
        end
        cab1 = corrcoef([a1(:),b1(:)]);
        cab1 = cab1(1,2);
        d_cab(k1,r1) = cab1;
        if cab1 > cab
            cab = cab1;
            xc = k;
            yc = r;
        end
    end
end
madcab = d_cab;
c = a*0;
xami = 1+xc;
xcmi = 1;
xama = xa+xc;
xcma = xa;
yami = 1+yc;
ycmi = 1;
yama = ya+yc;
ycma = ya;
if xami < 1
    xcmi = xcmi + 1 - xami;
    xami = 1;
end
if xama > xa
    xcma = xcma - (xama - xa);
    xama = xa;
end
if yami < 1
    ycmi = ycmi + 1 - yami;
    yami = 1;
end
if yama > ya
    ycma = ycma - (yama - ya);
    yama = ya;
end
c(xcmi:xcma,ycmi:ycma) = a(xami:xama,yami:yama);
end
function [a,b,s] = fit_2_para(mb,s1)
    n = numel(mb);
    switch n
        case 1
            a = -round(mb);
            b = round(mb);
            s = round(s1);
        case 2
            a = round(mb(1));
            b = round(mb(2));
            s = round(s1);
        case 3
            a = round(mb(1));
            b = round(mb(2));
            s = round(mb(3));
    end
end