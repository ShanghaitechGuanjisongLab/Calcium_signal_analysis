function [Tag] = Fun_pre(fname,Z_num,file_path,fi)

cd(file_path);
if fi == 1
    for ii = 1 : Z_num
        try
            rmdir(['Z' num2str(ii)],'s');
        catch
        end
        mkdir(['Z' num2str(ii)]);
    end
end
if fi == 1
    d = dir(file_path);
    isub = [d(:).isdir];
    nameFold = {d(isub).name}';
    l_nameFold = numel(nameFold);
    for k = 1:l_nameFold
        cname = 'tag';
        if strcmp(nameFold{k},cname)
            rmdir(cname, 's');
        end
    end
    mkdir(cname);
end
InfoImage = imfinfo(fname);
mImage = InfoImage(1).Width;
nImage = InfoImage(1).Height;
NumberImages=length(InfoImage);
lastlayer=length(InfoImage)/2;
if abs(round(lastlayer) - lastlayer) > 0.01
    fprintf(['The image has' num2str(length(InfoImage)) 'layers \n']);
    fprintf('The layer number of image is wrong! \n');
end

for iz = 1 : Z_num
    img = zeros(nImage,mImage,lastlayer/Z_num,'uint16');
    count = 1;
    for ic = iz : Z_num : lastlayer
       img(:,:,count)=imread(fname,'Index',ic);
       count=count+1;
    end
    
    cd([file_path '\Z' num2str(iz)]);
    for i=1:lastlayer/Z_num
      imwrite(img(:,:,i),['Z' num2str(iz) '_' fname],'WriteMode','append');
    end

end

img = zeros(nImage,mImage,lastlayer/Z_num,'uint16');
count = 1;
for i = lastlayer+1 : Z_num : 2 * lastlayer
    for j = 1 : Z_num
      img(:,:,count)=img(:,:,count)+imread(fname,'Index',i+j-1);
    end
    img(:,:,count)=img(:,:,count)/Z_num;
    count=count+1;
end

cd([file_path '\tag']);
Tag=[];
for i=1:lastlayer/Z_num
  Tag(i)=mean(mean(img(:,:,i)));
%       imwrite(img(:,:,i),[ 'Tag_' fname],'WriteMode','append');
end
save([fname(1:end-4) '_tag.mat'],'Tag');
figure;plot(Tag)
end