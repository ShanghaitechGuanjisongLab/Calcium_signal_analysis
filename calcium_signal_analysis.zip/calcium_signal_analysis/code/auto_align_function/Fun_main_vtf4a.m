%无拉伸
function [mean_img,std_img,bias,corrResults] = Fun_main_vtf4a(fname,img_base,fi)

mkdir('temp');
if fi == 1
	mkdir('stable');
	mkdir('stable_Z_project');
	mkdir('rotation_bas');
end
info=imfinfo(fname);
lastlayer=length(info);

if lastlayer > 100
	Nfl = 10; %每组5个文件%%%%%%%%% 80
else
	Nfl = 1;
end
Ng = ceil(lastlayer/Nfl);
temp_tif = cell(Ng,1);
for k = 1:Ng
	temp_tif{k} = zeros(512,512,Nfl,"uint16");
end

poolsize_chosen = 8;

% [~,TaskStarts,TaskEnds]=AllocateTasksFairly(lastlayer,Ng);
ReadClient=Tiff(fname);
for a=1:Ng-1
	for b=1:Nfl
		temp_tif{a}(:,:,b)=ReadClient.read;
		ReadClient.nextDirectory;
	end
end
for b=1:Nfl
	temp_tif{Ng}(:,:,b)=ReadClient.read;
	if ReadClient.lastDirectory
		ReadClient.close;
		temp_tif{Ng}=temp_tif{Ng}(:,:,1:b);
		break;
	else
		ReadClient.nextDirectory;
	end
end
NumFrame=lastlayer;

NBlk = NumFrame; %每100个文件分一组
% A = zeros(512,512,NumFrame,'uint16');


%% ref
www=pwd;
if exist([www '\imY1.mat'],'file')
	load imY1 imY1;
	disp('imY1 loaded');
else
	imY1=uint16(img_base);
end

%
%
%%
% pause;
% close all
save imY1 imY1;


if NumFrame > 1
	%%
	poolobj = gcp('nocreate'); % If no pool, do not create new one.
	if isempty(poolobj)||poolobj.NumWorkers<poolsize_chosen
		delete(poolobj);
		parpool(poolsize_chosen);
	end
end

corrResults = ones(1,NumFrame);
bias = zeros(NumFrame,2);

%rotation
%if fi == 1 %before 210608

% imY2 = zeros(512,512,'uint16');
% imY2(:,:) = temp_tif{1}(:,:,1);
if fi == 1
	img_base_i = Fun_main_lky_get_base(fname);
	[imY_base,Transformation] = MultimodalRegister(img_base_i,imY1,'rigid');

	figure;
	set(gcf,'position',[00 300 1500 600]);
	subplot(1,2,1);
	imagesc(imY1);colormap gray;
	subplot(1,2,2);
	imagesc(imY_base);colormap gray;
	imY_base = imY1; %%%%%%%%%%after 201223
% 	save(['rotation_bas/rotation_bas' num2str(fi) '.mat'],'imY_base',"Transformation");
	save('rotation_bas.mat','imY_base',"Transformation");
else
	load('rotation_bas.mat');
end

disp(NBlk);
last_NBlk = NBlk;

% xbias = zeros(1,last_NBlk);
% ybias = zeros(1,last_NBlk);
% corrResultsBlk = ones(1,last_NBlk);

Ablock = zeros(512,512,Nfl,Ng,'uint16');
xbb = zeros(Nfl,Ng);
ybb = zeros(Nfl,Ng);
% [xFixed,yFixed] = meshgrid(1:size(imY_base,2),1:size(imY_base,1));
% sumFixedIntensity = sum(imY_base(:));
% fixedXCOM = (fixedRefObj.PixelExtentInWorldX .* (sum(xFixed(:).*double(imY_base(:))) ./ sumFixedIntensity)) + fixedRefObj.XWorldLimits(1);
% fixedYCOM = (fixedRefObj.PixelExtentInWorldY .* (sum(yFixed(:).*double(imY_base(:))) ./ sumFixedIntensity)) + fixedRefObj.YWorldLimits(1);
% [optimizer, metric] = imregconfig('monomodal');
% %越小越容易飞
% optimizer.RelaxationFactor = 0.2;%步长缩短系数，默认0.5
% optimizer.MaximumIterations = 30;%最大迭代次数，默认100
% %越大越容易飞
% optimizer.GradientMagnitudeTolerance = 3;%平台期判定阈值，默认0.0001
% optimizer.MinimumStepLength = 0.02;%，最小步长，默认0.00001
% optimizer.MaximumStepLength = 0.8;%最大步长，默认0.0625
% crRb = ones(Nfl,Ng);
RefObj=imref2d(size(imY_base));
Fixed=double(imY_base);
while true
	try
		FixedGpu=gpuArray(Fixed);
		break;
	catch
	end
end
GpuSize=2;
Suffix="/"+string(NumFrame);
TaskBlock=zeros(poolsize_chosen,1,"uint16");
if poolsize_chosen>1
	Tasks=cell(poolsize_chosen,1);
	for a=1:min(poolsize_chosen,Ng)
		if a>GpuSize
			Tasks{a}=parfeval(@PartialRegisterCopy,3,RefObj,double(temp_tif{a}),Transformation);
		else
			Tasks{a}=parfeval(@PartialRegisterGpuCopy,3,RefObj,double(temp_tif{a}),Transformation);
		end
		TaskBlock(a)=a;
	end
	Tasks=vertcat(Tasks{:});
	for a=poolsize_chosen+1:Ng
		[TaskIndex,Registered,XTranslate,YTranslate]=fetchNext(Tasks);
		BlockIndex=TaskBlock(TaskIndex);
		Ablock(:,:,:,BlockIndex)=Registered;
		xbb(:,BlockIndex)=XTranslate;
		ybb(:,BlockIndex)=YTranslate;
		% 		disp(string((a-poolsize_chosen)*Nfl)+Suffix);
% 		fprintf('_');
		if mod(a*Nfl,100) == 0
			% 			disp(string(a*Nfl)+Suffix);
			fprintf('_');
		end
		if TaskIndex>GpuSize
			Tasks(TaskIndex)=parfeval(@PartialRegisterCopy,3,RefObj,double(temp_tif{a}),Transformation);
		else
			Tasks(TaskIndex)=parfeval(@PartialRegisterGpuCopy,3,RefObj,double(temp_tif{a}),Transformation);
		end
		TaskBlock(TaskIndex)=a;
	end
	for a=max(1,Ng-poolsize_chosen+1):Ng
		[TaskIndex,Registered,XTranslate,YTranslate]=fetchNext(Tasks);
		BlockIndex=TaskBlock(TaskIndex);
		Ablock(:,:,:,BlockIndex)=Registered;
		xbb(:,BlockIndex)=XTranslate;
		ybb(:,BlockIndex)=YTranslate;
		if mod(a*Nfl,100) == 0
			% 			disp(string(a*Nfl)+Suffix);
			fprintf('_');
		end
	end
else
	for a=1:Ng
		[Ablock(:,:,:,a),xbb(:,a),ybb(:,a)]=PartialRegisterGpuCopy(RefObj,double(temp_tif{a}),Transformation);
		if mod(a*Nfl,100) == 0
			% 			disp(string(a*Nfl)+Suffix);
			fprintf('_');
		end
	end
end
fprintf('\n');
% parfor ki=1:Ng %%%%%%%%%%%%%%%%%parfor
%     temp_tif1 = double(gpuArray(temp_tif{ki}));
%     xt = gather(size(temp_tif1,3));
%     Ablock1 = zeros(512,512,Nfl);
%     xbb1 = zeros(Nfl,1);
%     ybb1 = zeros(Nfl,1);
% %     crRb1 = zeros(Nfl,1);
%     for fi = 1:xt
% % 		if fi==61
% % 			fi=61;
% % 		end
%         imY2 = temp_tif1(:,:,fi);
%         imY2 = imwarp(imY2,RefObj, Transformation,"nearest", 'OutputView',RefObj);
%         [imY3,xc1,yc1] = Normxcorr2Register(imY2,imY_base,50);
%     %         imY3 = VtfRegisterInDay(imY2,imY_base);
%         Ablock1(:,:,fi) = imY3;
%         xbb1(fi) = xc1;
%         ybb1(fi) = yc1;
% %         crRb1(fi) = cab;
%         if mod((ki-1)*Nfl+fi,100) == 0
%           disp(string((ki-1)*Nfl+fi)+"/"+string(last_NBlk));
%         end
%     end
%     Ablock(:,:,:,ki) = uint16(Ablock1);
%     xbb(:,ki) = xbb1;
%     ybb(:,ki) =ybb1;
% %     crRb(:,ki) = crRb1;
% end
Ablock = reshape(Ablock,512,512,Nfl*Ng);
xbias = reshape(xbb,1,Nfl*Ng);
ybias = reshape(ybb,1,Nfl*Ng);
% corrResultsBlk = reshape(crRb,1,Nfl*Ng);

A = Ablock(:,:,1:last_NBlk);
% corrResults(1:last_NBlk) = corrResultsBlk(1:last_NBlk);
bias(1:last_NBlk,1) = xbias(1:last_NBlk);
bias(1:last_NBlk,2) = ybias(1:last_NBlk);
max_xbias = max(abs(xbias));
max_ybias = max(abs(ybias));
fprintf(['bias_size x:',num2str(max_xbias),' y:',num2str(max_ybias),'\n']);


%elapsedTime = toc;
%disp(['performance: ' num2str(elapsedTime/NumFrame*1000) ' seconds per 1000 frames']);

flnm=['stable/' fname];
%% 并行写Tiff再合并
TagStruct=struct("ImageWidth",width(A),"ImageLength",height(A),"Photometric",Tiff.Photometric.MinIsBlack,"Compression",Tiff.Compression.LZW,"PlanarConfiguration",Tiff.PlanarConfiguration.Chunky,"BitsPerSample",16,"SamplesPerPixel",1);
[~,TaskStarts,TaskEnds]=AllocateTasksFairly(size(A,3),poolsize_chosen);
Tasks=cell(poolsize_chosen,1);
for a=1:poolsize_chosen
	Tasks{a}=A(:,:,TaskStarts{a}:TaskEnds{a});
end
OutputPaths=strings(poolsize_chosen,1);
parfor a=1:poolsize_chosen
	Task=Tasks{a};
	OutputPath=flnm+"."+string(a);
	OutputPaths(a)=OutputPath;
	WriteClient=Tiff(OutputPath,"w8");
	for b=1:size(Task,3)
		WriteClient.setTag(TagStruct);
		WriteClient.write(Task(:,:,b));
		WriteClient.writeDirectory;
	end
	WriteClient.close;
end
TiffMerge(flnm,OutputPaths);
arrayfun(@delete,OutputPaths);
%%
std_flnm=['stable_Z_project/std_' fname];
mean_flnm=['stable_Z_project/mean_' fname];
std_img=uint16(std(double(A),0,3));
mean_img=uint16(mean(double(A),3));
imwrite(std_img,std_flnm);
imwrite(mean_img,mean_flnm);

save([fname '_bias.mat'],'bias','-v7.3');
disp('bias saved');


%%
rmdir('temp', 's');
%if exist('imY1.mat', 'file')
%delete('imY1.mat');
%disp('delete discline');
%end
% parpool close
%%
end