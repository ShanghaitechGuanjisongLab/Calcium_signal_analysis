function [mean_img,std_img,bias,corrResults] = Fun_main_vtf(fname,img_base,fi)

mkdir('temp');
if fi == 1
    mkdir('stable');
    mkdir('stable_Z_project');
end
firstlayer=1;
info=imfinfo(fname);
lastlayer=length(info);

temp_tif = zeros(512,512,lastlayer);
for ic=firstlayer:lastlayer
    gray=imread(fname,'Index',ic);
    temp_tif(:,:,ic) = gray;
%     parfor fi=1:last_NBlk %%%%%%%%%%%%%%%%%parfor
%         i = (si-1)*NBlk+fi;
%       fln=['temp/' num2str(ic) '.tif'];
%       imwrite(gray,fln);
end

NumFrame=lastlayer;

NBlk = 3600; %ÿ100���ļ���һ��
A = zeros(512,512,NumFrame,'uint16');
Ablock = zeros(512,512,NBlk,'uint16');

%% ref
www=pwd;
if exist([www '\imY1.mat'],'file')
    load imY1 imY1;
    disp('imY1 loaded');
else
    imY1=uint16(img_base);
end

% 
% 
%%
% pause;
% close all
save imY1 imY1;

if NumFrame > 1
    %%
    poolobj = gcp('nocreate'); % If no pool, do not create new one.
    if isempty(poolobj)
        poolsize = 0;
    else
        poolsize = poolobj.NumWorkers;
    end
    if poolsize > 0
        disp(['matlabpool size = ' int2str(poolsize)]);
    else
        parpool('local',10);
    end
end






corrResults = ones(1,NumFrame);

%tic;
bias = zeros(NumFrame,2);

%rotation
if fi == 1
    imY2 = zeros(512,512,'uint16');
    imY2(:,:) = temp_tif(:,:,1);
    imY1 = uint16(imY1);
    MovingReg = VtfRegisterBetweenDays(imY2,imY1);
    imY_base=MovingReg.RegisteredImage;
    Transformation=MovingReg.Transformation;
    %before 191107 save('rotation_bas.mat','xc','yc','rc');
%     save(['x',num2str(xc),'_y',num2str(yc),'_r',num2str(rc),'.mat'],'xc','yc','rc','imY_base');
    save('rotation_bas.mat','imY_base',"Transformation");
%     fprintf(['x',num2str(xc),'_y',num2str(yc),'_r',num2str(rc),'\n']);
    figure;
    set(gcf,'position',[00 300 1500 600]);
    subplot(1,2,1);
    imagesc(imY1);colormap gray;
    subplot(1,2,2);
    imagesc(imY_base);colormap gray;
else
    load('rotation_bas.mat');
end
for si=1:ceil(NumFrame/NBlk)
    disp(si*NBlk);
    
    
    
    if si*NBlk <= NumFrame
        last_NBlk = NBlk;
    else
        last_NBlk = NumFrame - (si - 1)*NBlk;
    end
    temp_tif1 = temp_tif(:,:,(si-1)*NBlk+1:(si-1)*NBlk+last_NBlk);
    xbias = zeros(1,last_NBlk);
    ybias = zeros(1,last_NBlk);
    corrResultsBlk = ones(1,last_NBlk);
    parfor fi=1:last_NBlk %%%%%%%%%%%%%%%%%parfor
%         i = (si-1)*NBlk+fi;
        imY2 = temp_tif1(:,:,fi);
        imY2=imwarp(imY2, imref2d(size(imY2)), Transformation, 'OutputView', imref2d(size(imY_base)), 'SmoothEdges', true);
        [imY3,cab,xc1,yc1,~] = fitxy_lky(double(imY2),double(imY_base),0,0,0);
%         imY3 = VtfRegisterInDay(imY2,imY_base);
        Ablock(:,:,fi) = imY3;
        xbias(fi) = xc1;
        ybias(fi) = yc1;
        corrResultsBlk(fi) = cab;
    end
    A(:,:,(si-1)*NBlk+(1:last_NBlk)) = Ablock(:,:,1:last_NBlk);
    corrResults((si-1)*NBlk+(1:last_NBlk)) = corrResultsBlk;
    bias((si-1)*NBlk+(1:last_NBlk),1) = xbias;
    bias((si-1)*NBlk+(1:last_NBlk),2) = ybias;
end

%elapsedTime = toc;
%disp(['performance: ' num2str(elapsedTime/NumFrame*1000) ' seconds per 1000 frames']);

flnm=['stable/' fname];
for i=1:lastlayer
    imwrite(A(:,:,i),flnm,'WriteMode','append');
end
std_flnm=['stable_Z_project/std_' fname];
mean_flnm=['stable_Z_project/mean_' fname];
std_img=uint16(std(double(A),0,3));
mean_img=uint16(mean(double(A),3));
imwrite(std_img,std_flnm,'WriteMode','append');
imwrite(mean_img,mean_flnm,'WriteMode','append');

save([fname '_bias.mat'],'bias','-v7.3');
disp('bias saved');


%%
rmdir('temp', 's');
%if exist('imY1.mat', 'file')
        %delete('imY1.mat');
        %disp('delete discline');
%end
% parpool close
%%
end