%拉伸
function [mean_img,std_img,bias,corrResults] = Fun_main_lky_transa(fname,img_base,fi)

if fi == 1
    mkdir('stable');
    mkdir('stable_Z_project');
end
info=imfinfo(fname);
lastlayer=length(info);

Nfl = 100; %每组5个文件
Ng = ceil(lastlayer/Nfl);
temp_tif = cell(Ng,1);
for k = 1:Ng
    temp_tif{k} = zeros(512,512,Nfl,"uint16");
end

poolsize_chosen = 10;

% [~,TaskStarts,TaskEnds]=AllocateTasksFairly(lastlayer,Ng);
ReadClient=Tiff(fname);
for a=1:Ng-1
    for b=1:Nfl
        temp_tif{a}(:,:,b)=ReadClient.read;
        ReadClient.nextDirectory;
    end
end
for b=1:Nfl
    temp_tif{Ng}(:,:,b)=ReadClient.read;
    if ReadClient.lastDirectory
        ReadClient.close;
        break;
    else
        ReadClient.nextDirectory;
    end
end
NumFrame=lastlayer;

NBlk = NumFrame; %每100个文件分一组
% A = zeros(512,512,NumFrame,'uint16');


%% ref
www=pwd;
if exist([www '\imY1.mat'],'file')
    load imY1 imY1;
    disp('imY1 loaded');
else
    imY1=uint16(img_base);
end

% 
% 
%%
% pause;
% close all
save imY1 imY1;


if NumFrame > 1
    %%
    poolobj = gcp('nocreate'); % If no pool, do not create new one.
    if isempty(poolobj)
        poolsize = 0;
    else
        poolsize = poolobj.NumWorkers;
    end
    if poolsize > 0
        disp(['matlabpool size = ' int2str(poolsize)]);
    else
        parpool('local',poolsize_chosen);
    end
end

corrResults = ones(1,NumFrame);
bias = zeros(NumFrame,2);

%rotation
if fi == 1
% 	imY2 = zeros(512,512,'uint16');
	imY2 = Fun_main_lky_get_base(fname);
	[imY_base,~,xc1,yc1,rc1] = fit_lky(double(imY2),double(imY1));
	[Displacement,imY_base] = imregdemons(imY_base,double(imY1),100,'AccumulatedFieldSmoothing',5,'PyramidLevels',4);
	[imY_base,~,xc2,yc2,rc2] = fit_lky(imY_base,double(imY1));
	save(['x',num2str(xc1),'_y',num2str(yc1),'_r',num2str(rc1),'.mat'],'xc1','yc1','rc1','imY_base');
	save(['rotation_bas.mat'],'xc1','yc1','rc1','xc2','yc2','rc2','imY_base','Displacement');
    figure;
    set(gcf,'position',[00 300 1500 600]);
    subplot(1,2,1);
    imagesc(imY1);colormap gray;
    subplot(1,2,2);
    imagesc(imY_base);colormap gray;
	pause(1);
else
	load('rotation_bas.mat');
end
imY_base = imY1;

disp(NBlk);
last_NBlk = NBlk;

% xbias = zeros(1,last_NBlk);
% ybias = zeros(1,last_NBlk);
% corrResultsBlk = ones(1,last_NBlk);

Ablock = zeros(512,512,Nfl,Ng,'uint16');
xbb = zeros(Nfl,Ng);
ybb = zeros(Nfl,Ng);
crRb = ones(Nfl,Ng);
parfor ki=1:Ng %%%%%%%%%%%%%%%%%parfor
    temp_tif1 = temp_tif{ki};
    xt = size(temp_tif1,3);
    Ablock1 = zeros(512,512,Nfl,'uint16');
    xbb1 = zeros(Nfl,1);
    ybb1 = zeros(Nfl,1);
    crRb1 = zeros(Nfl,1);
    for fi = 1:xt
        imY2 = temp_tif1(:,:,fi);
%         imY2 = imwarp(imY2, imref2d(size(imY2)), Transformation,"nearest", 'OutputView', imref2d(size(imY_base)), 'SmoothEdges', true);
		imY2a = rotate(double(imY2),xc1,yc1,rc1);
		imY2b = imwarp(imY2a,Displacement,"nearest");
		imY3 = rotate(imY2b,xc2,yc2,rc2);
% 		[imY3,cab,xc1a,yc1a] = fitxy_lky(imY2a,double(imY_base),0,0);
        Ablock1(:,:,fi) = imY3;
        xbb1(fi) = 0;
        ybb1(fi) = 0;
        crRb1(fi) = 0;
        if mod((ki-1)*Nfl+fi,100) == 0
          disp(string((ki-1)*Nfl+fi)+"/"+string(last_NBlk));
        end
    end
    Ablock(:,:,:,ki) = Ablock1;
    xbb(:,ki) = xbb1;
    ybb(:,ki) = ybb1;
    crRb(:,ki) = crRb1;
end
Ablock = reshape(Ablock,512,512,Nfl*Ng);
xbias = reshape(xbb,1,Nfl*Ng);
ybias = reshape(ybb,1,Nfl*Ng);
corrResultsBlk = reshape(crRb,1,Nfl*Ng);

A = Ablock(:,:,1:last_NBlk);
corrResults(1:last_NBlk) = corrResultsBlk(1:last_NBlk);
bias(1:last_NBlk,1) = xbias(1:last_NBlk);
bias(1:last_NBlk,2) = ybias(1:last_NBlk);


%elapsedTime = toc;
%disp(['performance: ' num2str(elapsedTime/NumFrame*1000) ' seconds per 1000 frames']);

flnm=['stable/' fname];
%% 并行写Tiff再合并
TagStruct=struct("ImageWidth",width(A),"ImageLength",height(A),"Photometric",Tiff.Photometric.MinIsBlack,"Compression",Tiff.Compression.LZW,"PlanarConfiguration",Tiff.PlanarConfiguration.Chunky,"BitsPerSample",16,"SamplesPerPixel",1);
[~,TaskStarts,TaskEnds]=AllocateTasksFairly(size(A,3),poolsize_chosen);
Tasks=cell(poolsize_chosen,1);
for a=1:poolsize_chosen
    Tasks{a}=A(:,:,TaskStarts{a}:TaskEnds{a});
end
OutputPaths=strings(poolsize_chosen,1);
parfor a=1:poolsize_chosen
    Task=Tasks{a};
    OutputPath=flnm+"."+string(a);
    OutputPaths(a)=OutputPath;
    WriteClient=Tiff(OutputPath,"w8");
    for b=1:size(Task,3)
        WriteClient.setTag(TagStruct);
        WriteClient.write(Task(:,:,b));
        WriteClient.writeDirectory;
    end
    WriteClient.close;
end
TiffMerge(flnm,OutputPaths);
arrayfun(@delete,OutputPaths);
%%
std_flnm=['stable_Z_project/std_' fname];
mean_flnm=['stable_Z_project/mean_' fname];
std_img=uint16(std(double(A),0,3));
mean_img=uint16(mean(double(A),3));
imwrite(std_img,std_flnm);
imwrite(mean_img,mean_flnm);

save([fname '_bias.mat'],'bias','-v7.3');
disp('bias saved');


%%
%if exist('imY1.mat', 'file')
        %delete('imY1.mat');
        %disp('delete discline');
%end
% parpool close
%%
end