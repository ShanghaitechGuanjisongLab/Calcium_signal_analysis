function [mean_img,std_img,bias] = Fun_main_xh_auto_align(fname)

if ~exist('temp', 'dir')
    mkdir('temp')
end

 firstlayer=1;
 info=imfinfo(fname);
 lastlayer=length(info);

for ic=firstlayer:lastlayer
      gray=imread(fname,'Index',ic);
      fln=['temp/' num2str(ic) '.tif'];  
      imwrite(gray,fln);
end

interlacingCorrection = 1;
NumFrame=lastlayer;

NBlk =100; %ÿ100���ļ���һ��
A = zeros(512,512,NumFrame,'uint16');
Ablock = zeros(512,512,NBlk,'uint16');

%% ref
refFrameRange = lastlayer;
www=pwd;
% if exist([www '\imY1.mat'],'file')
%     load imY1 imY1;
%     disp('imY1 loaded');
% else
    disp('get imY1 from original data ...');
    sumIm=zeros(512,512,refFrameRange);
    for i=1:refFrameRange
        imfileName=['temp/' num2str(i) '.tif']; 
        imX=imread(imfileName);
        sumIm(:,:,i)=imX;
    end
    
    chara=zeros(1,refFrameRange-1);
    for i=1:refFrameRange-1
        chara(i)=sum(sum(abs(sumIm(:,:,i+1)-sumIm(:,:,i))));
    end

    yes_id=0;

    for i=1:refFrameRange-1
        if abs(chara(i)-mean(chara))<3*std(chara);
            yes_id(i)=1;
        end
    end
    id_p=bwconncomp(yes_id);
    number = zeros(id_p.NumObjects,1);
    for i = 1:id_p.NumObjects
        number(i)=length(id_p.PixelIdxList{i});
    end
    [~,max_b]=max(number);
    everyIm=zeros(512,512);
    for i = 1+3: length(id_p.PixelIdxList{max_b(1)})-3
        everyIm(:,:)=everyIm(:,:)+double(sumIm(:,:,id_p.PixelIdxList{max_b(1)}(i)));
    end
    imY1=everyIm/(length(id_p.PixelIdxList{max_b(1)})-6);
% end
%% interlacing correction
if interlacingCorrection
    imY2 = imY1;
    odd = imY1(1:2:end,:)';
    even = imY1(2:2:end,:)';
    evenSub = even(5:end-10);%ƽ�Ʒ�Χ 5 +/- 4 pixel
    dataLenght = length(evenSub);
    ccA = zeros(1,9);
    for i = 1:9
        oddSub = odd((1:dataLenght)+i-1);
        cc = corrcoef(double(oddSub),double(evenSub));
        ccA(i) = cc(1,2);
    end
    [~,I] = max(ccA);
    % I = 4;
    ds = 5-I;% odd row move ds pixels to the right.
    disp(['interlacing shift:   ' int2str(ds) ' pixels.']);
    if ds==0
        interlacingCorrection = 0;
        disp('NO need for interlacing correction.');
    else
        if ds>0
            imY2(1:2:end,ds+1:end) = imY1(1:2:end,1:end-ds);
        elseif ds<0
            imY2(1:2:end,1:end+ds) = imY1(1:2:end,1-ds:end);
        end
    end
    % figure(3),imshow(imY2,[1 2000]);
    imY1 = imY2;
end
% 
% 
%%
% pause;
close all
save imY1 imY1;
%%
poolobj = gcp('nocreate'); % If no pool, do not create new one.
if isempty(poolobj)
    poolsize = 0;
else
    poolsize = poolobj.NumWorkers;
end
if poolsize > 0
    disp(['matlabpool size = ' int2str(poolsize)]);
else
    parpool('local',10);
end

pA1=imY1;
WIDTH = size(pA1,1);
HEIGHT = size(pA1,2);
margeSize=30;
pA1(WIDTH+1:WIDTH+margeSize*2,HEIGHT+1:HEIGHT+margeSize*2) = 0;
pA1(margeSize+1:WIDTH+margeSize,margeSize+1:HEIGHT+margeSize)=pA1(1:WIDTH,1:HEIGHT);
outsize=[500 500];
        
Side = 20;%%%%%%%%%%%%%%%%%%%%%
x1=Side+margeSize+1;
x2=WIDTH+margeSize-Side;
y1=Side+margeSize+1;
y2=WIDTH+margeSize-Side; 


corrResults = ones(1,NumFrame);

tic;
biasblock = zeros(NBlk,2);
bias = zeros(NumFrame,2);
for si=1:floor(NumFrame/NBlk)
    disp(si*NBlk);
    corrResultsBlk = ones(1,NBlk);
    parfor fi=1:NBlk %%%%%%%%%%%%%%%%%parfor
        i = (si-1)*NBlk+fi;

        %imN=num2str(i+1000000);
        %imfileName=[fileTP imN(2:7) '.ome.tif'];
        
        imfileName=['temp/' num2str(i) '.tif']; 
        imY2=double(imread(imfileName));
        %imY2=gram(:,:,i);
        if interlacingCorrection
            if ds>0
                imY2(1:2:end,ds+1:end) = imY2(1:2:end,1:end-ds);
            elseif ds<0
                imY2(1:2:end,1:end+ds) = imY2(1:2:end,1-ds:end);
            end
        end
        %Pad by repeating border elements of array.
        %this operation make sure no empty pixel in the results.
        pinput = padarray(imY2,[margeSize margeSize],'replicate','both');
        pinput = pinput(:,:);%%??????
        
        Fa_raw=pinput(y1:y2,x1:x2);
        Fb_raw=pA1(y1:y2,x1:x2);
        
        A_wgy=Fa_raw;
        for ii=1:2
            A_wgy=A_wgy+A_wgy([2:end 1],:)+A_wgy(:,[2:end 1])+A_wgy([end 1:end-1],:)+A_wgy(:,[end 1:end-1]);
            A_wgy=A_wgy/4;
        end
        Fa_raw=A_wgy;
            % calculate correlation in frequency domain
            Fa = fft2(rot90(Fa_raw,2),outsize(1),outsize(2));
            Fb = fft2(Fb_raw,outsize(1),outsize(2));
            c = real(ifft2(Fa .* Fb));
            [max_c, imax] = max(abs(c(:)));
            [ypeak_raw, xpeak_raw] = ind2sub(size(c),imax(1));
            rand_maxtrix=2*mean(Fb(:))*rand(x2-x1+1,x2-x1+1);
            Fa = fft2(rot90(rand_maxtrix,2),outsize(1),outsize(2));
            Fb = fft2(Fb_raw,outsize(1),outsize(2));
            c1 = real(ifft2(Fa .* Fb));
            c2=c-c1;
            c2(1:ypeak_raw-3*margeSize,:)=0;
            c2(:,1:xpeak_raw-3*margeSize)=0;
            [max_c2, imax] = max(abs(c2(:)));
            [ypeak, xpeak] = ind2sub(size(c2),imax(1));
            
            ref_end=x2-x1+1;
            xbias =  xpeak - ref_end;%-margeSize;
            ybias = ypeak - ref_end;%-margeSize;
            
            biasblock(fi,:)=[xbias ybias];

            if abs(xbias)>=margeSize || abs(ybias)>=margeSize
                corrResultsBlk(fi) = 0;
                disp('exception: exceed margeSize!');
                xbias = 0;
                ybias = 0;
            end                                
                    
            imY3=pinput((margeSize+1:WIDTH+margeSize)-ybias,(margeSize+1:HEIGHT+margeSize)-xbias);

            Ablock(:,:,fi) = imY3;
    end
    A(:,:,(si-1)*NBlk+(1:NBlk)) = Ablock;
    corrResults((si-1)*NBlk+(1:NBlk)) = corrResultsBlk;
    bias((si-1)*NBlk+(1:NBlk),:) = biasblock;
end

elapsedTime = toc;
disp(['performance: ' num2str(elapsedTime/NumFrame*1000) ' seconds per 1000 frames']);

if ~exist('stable', 'dir')
    mkdir('stable');
end
flnm=['stable/' fname];
for i=1:lastlayer
    imwrite(A(:,:,i),flnm,'WriteMode','append');
end
if ~exist('stable_Z_project', 'dir')
    mkdir('stable_Z_project');
end
std_flnm=['stable_Z_project/std_' fname];
mean_flnm=['stable_Z_project/mean_' fname];
std_img=uint16(std(double(A),0,3));
mean_img=uint16(mean(double(A),3));
imwrite(std_img,std_flnm,'WriteMode','append');
imwrite(mean_img,mean_flnm,'WriteMode','append');

save([fname '_bias.mat'],'bias','-v7.3');
disp('bias saved');


%%
rmdir('temp', 's');
%if exist('imY1.mat', 'file')
        %delete('imY1.mat');
        %disp('delete discline');
%end
% parpool close
%%
end