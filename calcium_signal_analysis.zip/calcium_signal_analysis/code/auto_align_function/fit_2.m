%aΪ������ͼ��bΪ��׼ͼ��
%cΪ������ͼ��cabΪ��ͼ������У׼�����ϵ����[xc,yc,rc]ΪУ������
%xmb,ymb,rmbΪx,y����ת��r�Ĳ���
%mb = aΪȡ����[-a,a],����Ĭ��
%mb = [a,b]Ϊȡ����[a,b],����Ĭ��
%mb = [a,b,s]Ϊȡ����[a,b],����Ϊs
function [c,cab,xc,yc,rc,madcab] = fit_2(a,b,xmb,ymb,rmb)
c = [];
[xa,ya] = size(a);
[xas,xae,xt] = fit_2_para(xmb,0.3);
[yas,yae,yt] = fit_2_para(ymb,0.3);
[ras,rae,rt] = fit_2_para(rmb,0.3);

p1 = 1/10; %before 200522 1/4
xbs = floor(xa*p1) + 1;%the base of x: start point
xbe = floor(xa*(1 - p1)) + 1;%the base of x: end point
ybs = floor(ya*p1) + 1;
ybe = floor(ya*(1 - p1)) + 1;
b1 = b(xbs:xbe,ybs:ybe);
cab = 0;
xc = 0;
yc = 0;
rc = 0;
d_cab = []; % data of corrcoef(a,b)
k1 = 0;
for k = xas:xt:xae
    k1 = k1 + 1;
    r1 = 0;
    for r = yas:yt:yae
        r1 = r1 + 1;
        s1 = 0;
        for s = ras:rt:rae
            s1 = s1 + 1;
            a1 = rotate_2(a,k,r,s,xbs,xbe,ybs,ybe);
            aa1 = a1(xbs:xbe,ybs:ybe);
            cab1 = corrcoef([aa1(:),b1(:)]);
            cab1 = cab1(1,2);
            d_cab(k1,r1,s1) = cab1;
            if cab1 > cab
                cab = cab1;
                xc = k;
                yc = r;
                rc = s;
            end
        end
    end
end
madcab = max(d_cab,[],3);
c = rotate(a,xc,yc,rc);
end
function [a,b,s] = fit_2_para(mb,s1)
    n = numel(mb);
    switch n
        case 1
            a = -mb;
            b = mb;
            s = s1;
        case 2
            a = mb(1);
            b = mb(2);
            s = s1;
        case 3
            a = mb(1);
            b = mb(2);
            s = mb(3);
    end
end