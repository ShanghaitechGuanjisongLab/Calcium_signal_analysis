function img_base = Fun_main_lky_get_base_slow(fname, align_frame)
arguments
	fname
	align_frame = 1000
end

mkdir('temp_lky');
% if fi == 1
%     mkdir('stable');
%     mkdir('stable_Z_project');
% end
firstlayer=1;
info=imfinfo(fname);
lastlayer=length(info);

NumFrame = min(lastlayer,align_frame);%��ǰ300ƽ����Ϊbase

for ic=firstlayer:NumFrame
      gray=imread(fname,'Index',ic);
      fln=['temp_lky/' num2str(ic) '.tif'];
      imwrite(gray,fln);
end

% NumFrame=lastlayer;


NBlk =10; %ÿ100���ļ���һ��
if NumFrame < NBlk
	NBlk = NumFrame;
end
A = zeros(512,512,NumFrame,'uint16');
Ablock = zeros(512,512,NBlk,'uint16');

%% ref
% www=pwd;
% if exist([www '\imY1.mat'],'file')
%     load imY1 imY1;
%     disp('imY1 loaded');
% else
%     imY1=double(img_base);
% end

% 
% 
%%
% pause;
% close all
% save imY1 imY1;
%%
poolobj = gcp('nocreate'); % If no pool, do not create new one.
if isempty(poolobj)
    poolsize = 0;
else
    poolsize = poolobj.NumWorkers;
end
if poolsize > 0
    disp(['matlabpool size = ' int2str(poolsize)]);
else
    parpool('local',10);
end

corrResults = ones(1,NumFrame);

%tic;
biasblock = zeros(NBlk,2);
bias = zeros(NumFrame,2);

% %rotation
% if fi == 1
%     i = 1;
%     imfileName=['temp_lky/' num2str(i) '.tif'];
%     imY2=double(imread(imfileName)); %%%%%%%%%%%%%%%%%%%%%
%     [imY_base,~,xc,yc,rc] = fit_lky(imY2,imY1);
%     %before 191107 save('rotation_bas.mat','xc','yc','rc');
%     save(['x',num2str(xc),'_y',num2str(yc),'_r',num2str(rc),'.mat'],'xc','yc','rc','imY_base');
%     save('rotation_bas.mat','xc','yc','rc','imY_base');
%     fprintf(['x',num2str(xc),'_y',num2str(yc),'_r',num2str(rc),'\n']);
%     figure;
%     set(gcf,'position',[00 300 1500 600]);
%     subplot(1,2,1);
%     imagesc(imY1);colormap gray;
%     subplot(1,2,2);
%     imagesc(imY_base);colormap gray;
% else
%     load('rotation_bas.mat');
% end

i = 1;
imfileName=['temp_lky/' num2str(i) '.tif'];
imY_base = double(imread(imfileName)); %%%%%%%%%%%%%%%%%%%%%
xc = 0;
yc = 0;
rc = 0;

for si=1:floor(NumFrame/NBlk)
    fprintf([num2str(si*NBlk) '\n']);
    corrResultsBlk = ones(1,NBlk);
    
    for fi=1:NBlk %%%%%%%%%%%%%%%%%parfor 20210704
        i = (si-1)*NBlk+fi;

        %imN=num2str(i+1000000);
        %imfileName=[fileTP imN(2:7) '.ome.tif'];
        
        imfileName=['temp_lky/' num2str(i) '.tif'];
        imY2=double(imread(imfileName)); %%%%%%%%%%%%%%%%%%%%%
		try
	        [imY3,~,~,~] = fitxy_lky_slow(double(imY2),double(imY_base),xc,yc);
		catch
			[imY3,~] = MultimodalRegister(double(imY2),double(imY_base),'rigid');
		end
%         imY3 = VtfRegisterInDay3(imY2,imY_base);
        Ablock(:,:,fi) = imY3;
    end
    A(:,:,(si-1)*NBlk+(1:NBlk)) = Ablock;
    corrResults((si-1)*NBlk+(1:NBlk)) = corrResultsBlk;
    bias((si-1)*NBlk+(1:NBlk),:) = biasblock;
end

%elapsedTime = toc;
%disp(['performance: ' num2str(elapsedTime/NumFrame*1000) ' seconds per 1000 frames']);
img_base = mean(A,3);

% flnm=['stable/' fname];
% for i=1:lastlayer
%     imwrite(A(:,:,i),flnm,'WriteMode','append');
% end
% std_flnm=['stable_Z_project/std_' fname];
% mean_flnm=['stable_Z_project/mean_' fname];
% std_img=uint16(std(double(A),0,3));
% mean_img=uint16(mean(double(A),3));
% imwrite(std_img,std_flnm,'WriteMode','append');
% imwrite(mean_img,mean_flnm,'WriteMode','append');
% 
% save([fname '_bias.mat'],'bias','-v7.3');
% disp('bias saved');
% 
% 
% %%
rmdir('temp_lky', 's');
%if exist('imY1.mat', 'file')
        %delete('imY1.mat');
        %disp('delete discline');
%end
% parpool close
%%
end