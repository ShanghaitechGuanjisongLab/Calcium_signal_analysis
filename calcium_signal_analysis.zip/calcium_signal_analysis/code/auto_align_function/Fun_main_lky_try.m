function [mean_img,std_img,bias] = Fun_main_lky_try(fname,img_base,fi)

mkdir('temp');
if fi == 1
    mkdir('stable');
    mkdir('stable_Z_project');
end
firstlayer=1;
info=imfinfo(fname);
lastlayer=length(info);

for ic=firstlayer:lastlayer
      gray=imread(fname,'Index',ic);
      fln=['temp/' num2str(ic) '.tif'];
      imwrite(gray,fln);
end

NumFrame=lastlayer;

NBlk =100; %ÿ100���ļ���һ��
A = zeros(512,512,NumFrame,'uint16');
Ablock = zeros(512,512,NBlk,'uint16');

%% ref
www=pwd;
imY1=double(img_base);


% 
% 
%%
% pause;
close all
%%
% poolobj = gcp('nocreate'); % If no pool, do not create new one.
% if isempty(poolobj)
%     poolsize = 0;
% else
%     poolsize = poolobj.NumWorkers;
% end
% if poolsize > 0
%     disp(['matlabpool size = ' int2str(poolsize)]);
% else
%     parpool('local',10);
% end

corrResults = ones(1,NumFrame);

%tic;
biasblock = zeros(NBlk,2);
bias = zeros(NumFrame,2);

%rotation
i = 1;
imfileName=['temp/' num2str(i) '.tif'];
imY2=double(imread(imfileName)); %%%%%%%%%%%%%%%%%%%%%
[imY_base,~,xc,yc,rc] = fit_lky(imY2,imY1,1/20);
%before 191107 save('rotation_bas.mat','xc','yc','rc');
save(['x',num2str(xc),'_y',num2str(yc),'_r',num2str(rc),'.mat'],'xc','yc','rc','imY_base');
save('rotation_bas.mat','xc','yc','rc','imY_base');
fprintf(['x',num2str(xc),'_y',num2str(yc),'_r',num2str(rc),'\n']);
% figure;
% set(gcf,'position',[00 300 1500 600]);
% subplot(1,2,1);
% imagesc(imY1);colormap gray;
% subplot(1,2,2);
% imagesc(imY_base);colormap gray;
% for si=1:floor(NumFrame/NBlk)
%     disp(si*NBlk);
%     corrResultsBlk = ones(1,NBlk);
%     
%     parfor fi=1:NBlk %%%%%%%%%%%%%%%%%parfor
%         i = (si-1)*NBlk+fi;
% 
%         %imN=num2str(i+1000000);
%         %imfileName=[fileTP imN(2:7) '.ome.tif'];
%         
%         imfileName=['temp/' num2str(i) '.tif'];
%         imY2=double(imread(imfileName)); %%%%%%%%%%%%%%%%%%%%%
%         [imY3,~,~,~,~] = fitxy_lky(imY2,imY_base,xc,yc,rc);
%         Ablock(:,:,fi) = imY3;
%     end
%     A(:,:,(si-1)*NBlk+(1:NBlk)) = Ablock;
%     corrResults((si-1)*NBlk+(1:NBlk)) = corrResultsBlk;
%     bias((si-1)*NBlk+(1:NBlk),:) = biasblock;
% end
% 
% %elapsedTime = toc;
% %disp(['performance: ' num2str(elapsedTime/NumFrame*1000) ' seconds per 1000 frames']);
NumFrame = 1;
A = zeros(512,512,NumFrame,'uint16');
A(:,:,1) = imY_base;
flnm=['stable/' fname];

for i=1:lastlayer
    imwrite(A(:,:,i),flnm,'WriteMode','append');
end

save([fname '_bias.mat'],'bias','-v7.3');
disp('bias saved');
mean_img = imY_base;
std_img = imY_base;

%%
rmdir('temp', 's');
%if exist('imY1.mat', 'file')
        %delete('imY1.mat');
        %disp('delete discline');
%end
% parpool close
%%
end