function [Tag] = Fun_pre_low_memory(fname,Z_num,file_path)

cd(file_path);
for ii = 1 : Z_num
    mkdir(['Z' num2str(ii)]);
end
    mkdir('tag');
    
InfoImage = imfinfo(fname);
mImage = InfoImage(1).Width;
nImage = InfoImage(1).Height;
NumberImages=length(InfoImage);
lastlayer=length(InfoImage)/2;

for iz = 1 : Z_num
    for ic = iz : Z_num : lastlayer
       img=imread(fname,'Index',ic);
       imwrite(img,['Z' num2str(iz) '_' fname],'WriteMode','append');
    end
end

    Tag=zeros(1,lastlayer/Z_num);
    for i = lastlayer+1 : Z_num : 2 * lastlayer
        for j = 1 : Z_num
        img=img+imread(fname,'Index',i+j-1);
        end
        img=img/Z_num;
        Tag(i)=mean(mean(img));
    end
    cd([file_path '\tag']);
    save([fname(1:end-4) '_tag.mat'],'Tag');
end