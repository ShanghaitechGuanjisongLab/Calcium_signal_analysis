function Tags = Fun_pre_tag_first(fname,Z_num,file_path,fi)
warning off;
TagDirectory=fullfile(file_path,"tag");
if fi == 1
    for ii = 1 : Z_num
		mkdir(fullfile(file_path,"Z"+string(ii)));
    end
    
	mkdir(TagDirectory);
end
InfoImage = imfinfo(fname);
mImage = InfoImage(1).Width;
nImage = InfoImage(1).Height;
lastlayer=length(InfoImage)/2;
if abs(round(lastlayer) - lastlayer) > 0.01
	fprintf(['The image has' num2str(length(InfoImage)) 'layers \n']);
	fprintf('The layer number of image is wrong! \n');
end
ReadPath=fullfile(file_path,fname);
WritePaths=strings(Z_num,1);
TagStruct=struct("ImageWidth",mImage,"ImageLength",nImage,"Photometric",Tiff.Photometric.MinIsBlack,"Compression",Tiff.Compression.LZW,"PlanarConfiguration",Tiff.PlanarConfiguration.Chunky,"BitsPerSample",16,"SamplesPerPixel",1);
for a=1:Z_num
	ZString="Z"+string(a);
	WritePaths(a)=fullfile(file_path,ZString,ZString+"_"+fname);
end
TimePoints=lastlayer/Z_num;
% NumWorkers=gcp().NumWorkers;
NumWorkers = 10;
[~,TaskStarts,TaskEnds]=AllocateTasksFairly(TimePoints,NumWorkers);
OutputPaths=strings(Z_num,NumWorkers);
parfor a=1:NumWorkers
warning off;
	ReadClient=Tiff(ReadPath);
	OPs=WritePaths+"."+string(a);
	WriteClients=arrayfun(@(Path)Tiff(Path,"w8"),OPs);
	OutputPaths(:,a)=OPs;
	TS=double(TaskStarts{a});
	if TS==1
		ReadClient.setDirectory(lastlayer+1); %tag first
		for b=1:Z_num-1
			WC=WriteClients(b);
			WC.setTag(TagStruct);
			WC.write(ReadClient.read);
			WC.writeDirectory;
			ReadClient.nextDirectory;
		end
		WC=WriteClients(Z_num);
		WC.setTag(TagStruct);
		WC.write(ReadClient.read);
		WC.writeDirectory;
		TS=TS+1;
    end
    ReadClient.setDirectory((TS-1)*Z_num+lastlayer);  %tag first
    
	for b=1:TaskEnds{a}-TS+1
		for c=1:Z_num
			ReadClient.nextDirectory;
			WC=WriteClients(c);
			WC.setTag(TagStruct);
			WC.write(ReadClient.read);
			WC.writeDirectory;
		end
	end
	ReadClient.close;
	arrayfun(@close,WriteClients);
end
parfor a=1:Z_num
	OPs=OutputPaths(a,:);
	TiffMerge(WritePaths(a),OPs);
	arrayfun(@delete,OPs);
end
Tags=cell(NumWorkers,1);
parfor a=1:NumWorkers
	warning off;
	ReadClient=Tiff(ReadPath);
	TS=double(TaskStarts{a});
	ReadClient.setDirectory(1+(TS-1)*Z_num); %%tag_first
	TPs=TaskEnds{a}-TS+1;
	Tag=zeros(TPs,Z_num);
	for b=1:TPs
		for c=1:Z_num
			Tag(b,c)=mean(ReadClient.read,"all");
            ReadClient.nextDirectory;
		end
	end
	Tags{a}=mean(Tag,2);
	ReadClient.close;
end
Tags=cell2mat(Tags);
save(TagDirectory,'Tags');
end