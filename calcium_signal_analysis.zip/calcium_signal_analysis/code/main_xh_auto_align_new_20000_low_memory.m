% %%This Program correct the scanline shift and XY shift. 

%
file_path = uigetdir('','Select data path'); 
addpath(genpath(file_path));
cd(file_path);
filelist = dir([file_path '\*.tif']);

filelist=struct2cell(filelist);
filelist=filelist(1,:);
trial_number=length(filelist);
Z_num = input('Enter number of piezo Z number :\n');

%%
% if Z_num > 1

    for fi = 1:trial_number
        tag=Fun_pre_low_memory(filelist{fi},Z_num,file_path);
    end

%%
    for ii = 1 : Z_num
        path_new=[file_path '\Z' num2str(ii) ];
        filelist_new = dir([path_new '\*.tif']);
        filelist_new=struct2cell(filelist_new);
        filelist_new=filelist_new(1,:);
        cd(path_new);
        
        for fi = 1:length(filelist_new)
            [mean_img,std_img,bias]=Fun_main_xh_auto_align_new_20000(filelist_new{fi});
        end
    
    end


