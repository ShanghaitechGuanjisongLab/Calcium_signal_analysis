function a = cell_movie(d1)
xx1 = 0:numel(d1)-1;
xx = 0:0.5:numel(d1)-0.5;
yy = spline(xx1,d1,xx);

line_wide = 1/2;
xn = -4:0.1:4;
yn = normpdf(xn,0,1*line_wide);
yn = yn / max(yn);

show_len = 400;
blank_x = 112;
show_x = 400;
show_y = 100;
top_brightness = 255;
dx = round(show_len/show_x);
fig_len = numel(yy);

miny = min(yy);
maxy = max(yy);
dy = (maxy - miny)/(show_y-7);

a = zeros(show_y,show_x+blank_x,fig_len)*top_brightness;
fprintf('Movie is loading...\n');
for k = 1:fig_len
    if mod(k,round(fig_len/100)) == 0
        fprintf('_');
    end
    if mod(k,round(fig_len/10)) == 0
        fprintf([num2str(k/round(fig_len/10)) '/10 ']);
		if k/round(fig_len/10) == 5
			fprintf('\n');
		end
    end
    if k < 1+dx*(show_len - 1)
        xlen = floor((k - 1)/dx)+1;
        xx1 = 1:xlen;
        yya = yy(1:dx:1+dx*(xlen-1));
    else
        xx1 = 1:show_len;
        yya = yy(k - dx*(show_len - 1):dx:k);
    end
    yy1 = show_y - (yya - miny)/dy+3.5;
    for r = 1:numel(xx1)
        yyr = floor(yy1(r));
        ry1 = floor((yy1(r) - yyr)*10);
        for s = -3:3
            cs = sum(yn(41-ry1+s*10:41-ry1+(s+1)*10-1))/10;
            a(yyr+s,xx1(r),k) = floor(cs*top_brightness);
        end
        if r > 1
            if yy1(r) > yy1(r - 1)
                dsx = floor(yy1(r)-yy1(r-1));
                xn1 = -dsx-4:0.1:dsx+4;
                yn1 = normpdf(xn1,0,(dsx+1)*line_wide);
                yn1 = yn1/max(yn1);
                for s = 0:dsx+2
                    cs = sum(yn1(10*(dsx+4)+1-ry1b+s*10:10*(dsx+4)+1-ry1b+(s+1)*10-1))/10;
                    a(yyrb+s,xx1(r-1),k) = max(a(yyrb+s,xx1(r-1),k),floor(cs*top_brightness));
                end
                for s = -(dsx+2):0
                    cs = sum(yn1(10*(dsx+4)+1-ry1+s*10:10*(dsx+4)+1-ry1+(s+1)*10-1))/10;
                    a(yyr+s,xx1(r),k) = max(a(yyr+s,xx1(r),k),floor(cs*top_brightness));
                end
            else
                dsx = floor(yy1(r-1)-yy1(r));
                xn1 = -dsx-4:0.1:dsx+4;
                yn1 = normpdf(xn1,0,dsx+1);
                yn1 = yn1/max(yn1);
                for s = -(dsx+2):0
                    cs = sum(yn1(10*(dsx+4)+1-ry1b+s*10:10*(dsx+4)+1-ry1b+(s+1)*10-1))/10;
                    a(yyrb+s,xx1(r-1),k) = max(a(yyrb+s,xx1(r-1),k),floor(cs*top_brightness));
                end
                for s = 0:dsx+2
                    cs = sum(yn1(10*(dsx+4)+1-ry1+s*10:10*(dsx+4)+1-ry1+(s+1)*10-1))/10;
                    a(yyr+s,xx1(r),k) = max(a(yyr+s,xx1(r),k),floor(cs*top_brightness));
                end
            end
        end
        yyrb = yyr;
        ry1b = ry1;
    end
    
end

fprintf('\n');
fprintf('Movie is being saved...\n');
a = uint8(a);

% for k = 1:fig_len
%     if k == 1
%         imwrite(a(:,:,k),fname);
%     else
%         imwrite(a(:,:,k),fname,'WriteMode','append');
%     end
% end
