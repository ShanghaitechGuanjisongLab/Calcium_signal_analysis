%Granger Causility
function [f,sig,pval] = mvgc_func(data,cell_ID)
%%
% input var:
% data: Calcium data. 3 dimention array formed as frame*cell*block.
% cell_ID: Cell ID. Formed as [a1,a2,...].
% output var:
% f: Weight. f(n1,n2,fn) means the causity from n2 to n1 on the frequency of fn/fps.
% sig: Significance. 1:Yes, 0:no. sig(n1,n2) means the causity significance from n2 to n1.
% pval: P-value. The same as sig.


nvars = numel(cell_ID);

[xd,~,zd] = size(data);
ntrials   = zd;     % number of trials
nobs      = xd;   % number of observations per trial

regmode   = 'LWR';  % VAR model estimation regression mode ('OLS', 'LWR' or empty for default)
icregmode = 'LWR';  % information criteria regression mode ('OLS', 'LWR' or empty for default)

morder    = 'AIC';  % model order to use ('actual', 'AIC', 'BIC' or supplied numerical value)
momax     = 20;     % maximum model order for model order estimation

acmaxlags = [];   % maximum autocovariance lags (empty for automatic calculation)

tstat     = '';     % statistical test for MVGC:  'F' for Granger's F-test (default) or 'chi2' for Geweke's chi2 test
alpha     = 0.01;   % significance level for significance test
mhtc      = 'FDR';  % multiple hypothesis test correction (see routine 'significance')

% fs        = 30;    % sample rate (Hz)
fres      = [];     % frequency resolution (empty for automatic calculation)

X = zeros(nvars,nobs,ntrials);


for k = 1:ntrials
    for r = 1:nvars
		r1 = cell_ID(r);
        d1 = data(1:nobs,r1,k);
        d1 = (d1 - mean(d1))/mean(d1);
        X(r,:,k) = d1;
    end
end

%% Model order estimation (<mvgc_schema.html#3 |A2|>)

% Calculate information criteria up to specified maximum model order.

[~,~,moAIC,~] = tsdata_to_infocrit_nonoutput(X,momax,icregmode);

% Plot information criteria.
% Select model order.

morder = moAIC;

%% VAR model estimation (<mvgc_schema.html#3 |A2|>)

% Estimate VAR model of selected order from data.

[A,SIG] = tsdata_to_var(X,morder,regmode);

% Check for failed regression

assert(~isbad(A),'VAR estimation failed');

% NOTE: at this point we have a model and are finished with the data! - all
% subsequent calculations work from the estimated VAR parameters A and SIG.

%% Autocovariance calculation (<mvgc_schema.html#3 |A5|>)

% The autocovariance sequence drives many Granger causality calculations (see
% next section). Now we calculate the autocovariance sequence G according to the
% VAR model, to as many lags as it takes to decay to below the numerical
% tolerance level, or to acmaxlags lags if specified (i.e. non-empty).

[G,info] = var_to_autocov(A,SIG,acmaxlags);

% The above routine does a LOT of error checking and issues useful diagnostics.
% If there are problems with your data (e.g. non-stationarity, colinearity,
% etc.) there's a good chance it'll show up at this point - and the diagnostics
% may supply useful information as to what went wrong. It is thus essential to
% report and check for errors here.
if info.error
    fprintf(2,'    ERROR: %s\n',info.errmsg);
end
if info.warnings > 0
	for n = 1:info.warnings
        fprintf(2,'    WARNING: %s\n',info.warnmsg{n});
	end
end
assert(~(info.error && abort_on_error),'VAR info: aborting on error.');

%% Granger causality calculation: time domain  (<mvgc_schema.html#3 |A13|>)

% Calculate time-domain pairwise-conditional causalities - this just requires
% the autocovariance sequence.
F = autocov_to_pwcgc(G);

% Check for failed GC calculation

assert(~isbad(F,false),'GC calculation failed');

% Significance test using theoretical null distribution, adjusting for multiple
% hypotheses.

pval = mvgc_pval(F,morder,nobs,ntrials,1,1,nvars-2,tstat); % take careful note of arguments!
sig  = significance(pval,alpha,mhtc);

% Plot time-domain causal graph, p-values and significance.

% For good measure we calculate Seth's causal density (cd) measure - the mean
% pairwise-conditional causality. We don't have a theoretical sampling
% distribution for this.

%% Granger causality calculation: frequency domain  (<mvgc_schema.html#3 |A14|>)

% Calculate spectral pairwise-conditional causalities at given frequency
% resolution - again, this only requires the autocovariance sequence.

f = autocov_to_spwcgc(G,fres);

assert(~isbad(f,false),'spectral GC calculation failed');

Fint = smvgc_to_mvgc(f); % integrate spectral MVGCs
mad = maxabs(F-Fint);
madthreshold = 1e-5;
if mad > madthreshold
    fprintf(2,'WARNING: high maximum absolute difference = %e.2 (> %.2e)\n',mad,madthreshold);
end

%%
% <mvgc_demo.html back to top>
