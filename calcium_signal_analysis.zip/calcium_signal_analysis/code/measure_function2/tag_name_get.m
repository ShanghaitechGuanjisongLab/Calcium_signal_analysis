function [name] = tag_name_get(tag)
t_name(1,1).n = 'bas';
t_name(2,1).n = 'air';
t_name(3,1).n = 'blue';
t_name(3,2).n = 'yellow';
t_name(3,3).n = 'blue+blue';
t_name(3,4).n = 'blue+yellow';
t_name(3,5).n = 'blue+aud';
t_name(4,1).n = 'aud';
t_name(5,1).n = 'blue_air';
t_name(5,2).n = 'yellow_air';
t_name(6,1).n = 'aud_air';
t_name(7,1).n = 'blue_yellow';
t_name(7,2).n = 'blue_blue';
t_name(7,3).n = 'yellow_blue';
t_name(7,4).n = 'aud_blue';
t_name(7,5).n = 'blue_aud';
t_name(7,6).n = 'aud_yellow';
t_name(7,7).n = 'yellow_aud';
t_name(7,8).n = 'blue_aud+yellow';
t_name(7,9).n = 'blue_air+aud';
t_name(7,10).n = 'blue_aud_yellow';
t_name(7,11).n = 'blue_air_yellow';
t_name(7,12).n = 'blue_air_aud';
t_name(8,1).n = 'air_aud';
t_name(8,2).n = 'air_blue';


nt = numel(tag(1).type);
name = [];
for k = 1:nt
	txt1 = num2str(k);
	if k < 10
		txt1 = ['0', txt1];
	end
	txt2 = t_name(tag(1).type(k),tag(1).t_no(k)).n;
	txt_al = [txt1,'_',txt2];
	name = [name; {txt_al}];
end
end
