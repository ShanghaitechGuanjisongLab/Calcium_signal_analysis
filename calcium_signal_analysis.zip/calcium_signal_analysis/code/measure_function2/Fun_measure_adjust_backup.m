%修改第二行，然后运行即可
clear;
fprintf('Please input the data name.\n');
fprintf('The format is as follows:''date_mouse_operation_region''. example: 20201201_LVIP1_postCNO_Z1)\n');
data_name = input('data_name = ','s');
for k = 1:10
	try
		fprintf('Please input the stimuli type and type_no\n');
		fprintf('Note: the same as Line 6 and Line 7 of E:/LKY/ana_data/name_write.m\n');
		type1 = input('tag(1).type = ','s');
		t_no1 = input('tag(1).t_no = ','s');
		eval(['tag(1).type = ' type1]);
		eval(['tag(1).t_no = ' t_no1]);
		if numel(tag(1).type) ~= numel(tag(1).t_no)
			fprintf('The number of type should be the same as the number of t_no\n');
			a = iamwrong(1);
		end
		break;
	catch
		fprintf('Failed to save. Please try again. Or ask LKY for help. \n');
	end
end
[name] = tag_name_get(tag);
[tag_file_name,tag_path] = uigetfile('*.mat','Select tag data: *.mat');
data_path = tag_path(1:end - 4);
cd(data_path);
[roi_file_name,roi_path] = uigetfile('*.zip','Select RoiSet*.zip');
tif_path = uigetdir('','select tif path');
note = input('note(more information, any format):','s');
fprintf(['                               ' data_name]);
fprintf('\n');
real_mat_name = ['data_' data_name '_adjust2'];
data_date = data_name(1:8);
base_path = 'E:\LKY\ana_data';
Tag_path = fullfile(tag_path,tag_file_name);
RoiSetPath = fullfile(roi_path,roi_file_name);

load(Tag_path);
tag_name = ['tag_sum_' data_date];
real_data_name = real_mat_name;
%%GPU select
GPU_available = 0;
try
	load('E:\LKY\GPU_marker\GPU_marker.mat');
	if GPU_marker == 0
		fprintf(['GPU loading...\n']);
		GPU_marker = 1;
		save('E:\LKY\GPU_marker\GPU_marker.mat','GPU_marker');
		GPU_available = 1;
	end
catch
	fprintf(['GPU loading...\n']);
	GPU_marker = 1;
	save('E:\LKY\GPU_marker\GPU_marker.mat','GPU_marker');
	GPU_available = 1;
end
if GPU_available == 0
	[path,neurons,cell_edgex,cell_edgey,measure_data] = Format_ImageJ_ROI_adjust_CPU2(tif_path,RoiSetPath);
else
	[path,neurons,cell_edgex,cell_edgey,measure_data] = Format_ImageJ_ROI_adjust_GPU2(tif_path,RoiSetPath);
end

file_path = path;
% addpath(genpath(file_path));
% cd(file_path);
u = measure_data;
eval([real_data_name ' = u;']);
cd(base_path);

eval([tag_name ' = tag_sum;']);
eval(['save(''' real_data_name '.mat'',''' real_data_name ''',''name'',''tag'',''cell_edgex'',''cell_edgey'',''' tag_name ''',''note'');'])
cd(file_path);