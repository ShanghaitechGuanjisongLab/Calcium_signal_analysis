base_path = 'D:\LZ\ana';
real_mat_name = ['data_' data_name '_adjust2'];
data_date = data_name(1:8);
load(Tag_fullfile);
tag_name = ['tag_sum_' data_date];
real_data_name = real_mat_name;
%%GPU select
GPU_available = 0;
try
	load('D:\LZ\GPU_marker\GPU_marker.mat');
	if GPU_marker == 0
		GPU_available = 1;
	end
catch
	GPU_available = 1;
end
if GPU_available == 0
	[path,neurons,cell_edgex,cell_edgey,measure_data] = Format_ImageJ_ROI_adjust_CPU2(tif_path,RoiSetPath);
else
	fprintf(['GPU loading...\n']);
	GPU_marker = 1;
	save('D:\LZ\GPU_marker\GPU_marker.mat','GPU_marker');
	[path,neurons,cell_edgex,cell_edgey,measure_data] = Format_ImageJ_ROI_adjust_GPU2(tif_path,RoiSetPath);
	fprintf(['GPU is turned off.\n']);
	GPU_marker = 0;
	save('D:\LZ\GPU_marker\GPU_marker.mat','GPU_marker');
end

file_path = path;
% addpath(genpath(file_path));
% cd(file_path);
u = measure_data;
eval([real_data_name ' = u;']);
cd(base_path);

try
    eval([tag_name ' = tag_sum;']);
catch
    eval([tag_name ' = [];']);
end
eval(['save(''' real_data_name '.mat'',''' real_data_name ''',''name'',''tag'',''cell_edgex'',''cell_edgey'',''' tag_name ''',''note'');'])
cd(file_path);