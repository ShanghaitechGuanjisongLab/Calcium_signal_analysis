%% part 1 vector similarity score
show_button = 2;

u_list = [];

for r = 1:max(BlockGroups)
    
    
    for t = 1:max(BlockGroups)
        u = [];

        frame_chosen = 2*fps+2:3*fps+2;
        u1 = [];
        for s = 1:size(Dataset{t},3)
            a = mean(Dataset{t}(:,frame_chosen,s),2)';
            if t ~= r
                [~,sno1] = sort(rand(1,size(Dataset{r},3)));
                s1 = sno1(1:min_num);
                b1 = mean(Dataset{r}(:,frame_chosen,s1),2);
                b1 = reshape(b1,size(b1,1),size(b1,3));
                b = vmain(b1,2)';
            else
                s2 = setdiff(1:size(Dataset{t},3),s);
                [~,sno1] = sort(rand(1,numel(s2)));
                s1 = s2(sno1(1:min_num));
                b1 = mean(Dataset{r}(:,frame_chosen,s1),2);
                b1 = reshape(b1,size(b1,1),size(b1,3));
                b = vmain(b1,2)';
            end
            v = a*b'/(a*a')^(1/2)/(b*b')^(1/2);
            u1 = [u1; v];
        end



        u_list{r}{t} = u1;
    end
    
end

color1 = [];
for r = 1:max(BlockGroups)
    color1{r} = LineColors(r_list(r),:);
end

u_list1 = [];


u = u_list{r};
for t = 1:max(BlockGroups)
    u_list1{t} = u_list{t}{t};
end


if show_button > 1
    figure;
    fill_bar(u_list1,color1);
    hold on;
    axis square;
    axis([.5 max(BlockGroups)+.5 0 .6]);
    pause(0.4);
end

% for r = 1:max(BlockGroups)
%     if show_button > 1
%         figure;
%     end
%     u = u_list{r};
%     if show_button > 1
%         plot_data2(u);
%         hold on;
%         axis square;
%         pause(0.4);
%     end
%     
% end



u_list2 = [];
for r = 1:max(BlockGroups)
    if show_button > 0
        figure;
    end
    u = u_list{r};
    for t = 1:max(BlockGroups)
        
        u1 = mean(u_list{t}{t});

        u{t} = u{t}/u1;
%         u{t} = u1./u{t};
        
        u_list2{r}{t} = u{t};
    end
    if show_button > 0
        fill_bar(u,color1);
        hold on;
        axis square;
%         axis([.5 max(BlockGroups)+.5 -1 2]);
        axis([.5 max(BlockGroups)+.5 0 1.5]);
        pause(0.4);
    end
end

% u_list2{a} similarity with a