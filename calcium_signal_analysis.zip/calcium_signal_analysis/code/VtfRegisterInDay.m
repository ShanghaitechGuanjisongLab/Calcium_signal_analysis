function [RegisteredImage,TranslateX,TranslateY] = VtfRegisterInDay(MOVING,FIXED)
arguments
	MOVING(:,:)uint16
	FIXED(:,:)uint16
end
persistent optimizer metric
if isempty(optimizer)
	[optimizer, metric] = imregconfig('monomodal');
    %越小越容易飞
	optimizer.RelaxationFactor = 0.2;%步长缩短系数，默认0.5
	optimizer.MaximumIterations = 50;%最大迭代次数，默认100
    %越大越容易飞
	optimizer.GradientMagnitudeTolerance = 0.01;%平台期判定阈值，默认0.0001
	optimizer.MinimumStepLength = 0.002;%，最小步长，默认0.00001
	optimizer.MaximumStepLength = 0.1;%最大步长，默认0.0625
end
fixedRefObj = imref2d(size(FIXED));
movingRefObj = imref2d(size(MOVING));

% Align centers
[xFixed,yFixed] = meshgrid(1:size(FIXED,2),1:size(FIXED,1));
[xMoving,yMoving] = meshgrid(1:size(MOVING,2),1:size(MOVING,1));
sumFixedIntensity = sum(FIXED(:));
sumMovingIntensity = sum(MOVING(:));
fixedXCOM = (fixedRefObj.PixelExtentInWorldX .* (sum(xFixed(:).*double(FIXED(:))) ./ sumFixedIntensity)) + fixedRefObj.XWorldLimits(1);
fixedYCOM = (fixedRefObj.PixelExtentInWorldY .* (sum(yFixed(:).*double(FIXED(:))) ./ sumFixedIntensity)) + fixedRefObj.YWorldLimits(1);
movingXCOM = (movingRefObj.PixelExtentInWorldX .* (sum(xMoving(:).*double(MOVING(:))) ./ sumMovingIntensity)) + movingRefObj.XWorldLimits(1);
movingYCOM = (movingRefObj.PixelExtentInWorldY .* (sum(yMoving(:).*double(MOVING(:))) ./ sumMovingIntensity)) + movingRefObj.YWorldLimits(1);
translationX = fixedXCOM - movingXCOM;
translationY = fixedYCOM - movingYCOM;

initTform = affine2d();
initTform.T(3,1:2) = [translationX, translationY];

Transformation = imregtform(MOVING,movingRefObj,FIXED,fixedRefObj,'translation',optimizer,metric,'PyramidLevels',3,'InitialTransformation',initTform);
RegisteredImage = imwarp(MOVING, movingRefObj, Transformation,"nearest", 'OutputView', fixedRefObj, 'SmoothEdges', true);
TMatrix=Transformation.T;
TranslateX=TMatrix(3,1);
TranslateY=TMatrix(3,2);
end